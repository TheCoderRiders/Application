package com.hc.bpl.doa;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.jsoup.Jsoup;

import com.hc.bpl.dto.Document;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class DocumentDao {

	private Connection conn;
	private ConfigManager configManager;
	private String updatequery;
	public DocumentDao(Connection conn) {
		configManager=ConfigManager.getInstance();
		updatequery=configManager.getPropertie(Constants.DOCUMENTUPDATEQUERY);
		this.conn=conn;
	}


	public  List<Document> getDcuoment(String selectQuery) throws SQLException	{
		PreparedStatement prepareStatement=null;
		List<Document> documentList=new ArrayList<Document>();
		try { 
			prepareStatement =conn.prepareStatement(selectQuery);
			ResultSet rs=prepareStatement .executeQuery();
			while (rs.next()) {
			
				Document document=new Document();
				document.setDocument_id(rs.getString("document_id"));
				document.setDocument_html_contain(rs.getString("document_html_contents"));
				document.setId(rs.getInt("id"));
				document.setDocument_contain(rs.getString("document_contents"));
				documentList.add(document);
			}
			return documentList;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(prepareStatement!=null){
				try {
					prepareStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}

	}

	public int getCount(String selectQuery) throws SQLException	{
		PreparedStatement prepareStatement=null;
		int i=0;
		try { 
			prepareStatement =conn.prepareStatement(selectQuery);
			ResultSet rs=prepareStatement .executeQuery();
			while (rs.next()) {
				i=rs.getInt(1);
			}
			return i;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(prepareStatement!=null){
				try {
					prepareStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}

	}


	public void close(){
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	public void updateDocuments(List<Document> documentList) throws Exception{

		ObjectMapper mapper = null;
		ByteArrayOutputStream s=null;
		Statement simpleStatement=null;
		try{
			mapper = new ObjectMapper();
			s=new ByteArrayOutputStream();
			simpleStatement=conn.createStatement();
			for (Document document : documentList) {
				try{
					simpleStatement.executeUpdate(createQuery(updatequery,document,mapper,s));
				}catch(Exception e){
					System.out.println(e.getMessage());
				}

			}	
		}catch(Exception e){	
			throw e;
		}
	}


	public  String createQuery(String updateQuery,Document document, ObjectMapper mapper, ByteArrayOutputStream s) throws IOException{
		updateQuery=updateQuery.replace("__id__", document.getId()+"");
		try {
			mapper.writeValue( s, document.getSectionAutoSuggest());
			updateQuery=updateQuery.replace("__document_suggested_codes__",new String(s.toByteArray())).replace("__document_html_contents__", document.getDocument_html_contain());
			s.flush();
			s.reset();
			mapper.writeValue( s, document.getMaySectionAutoSuggest());
			updateQuery=updateQuery.replace("_document_may_be_codes_", new String(s.toByteArray()));
			s.flush();
			s.reset();
		} catch (JsonGenerationException e) {
			e.printStackTrace();
			throw e;
		} catch (JsonMappingException e) {
			e.printStackTrace();
			throw e;
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}

		return updateQuery;
	}
}
