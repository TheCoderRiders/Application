package com.hc.bpl.analysis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hc.bpl.dto.Document;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class SectionAnalysisFactroy implements AnalysisFactory{
	private	Pattern pattern;
	private	Pattern worktype;
	private ConfigManager configManager;
	public SectionAnalysisFactroy(){
		configManager=ConfigManager.getInstance();
		pattern=Pattern.compile(configManager.getPropertie(Constants.SECTIONPATTERN));
		worktype=Pattern.compile(configManager.getPropertie(Constants.WORKTYPEPATTERN));
	}
	@Override
	public void analysisDocument(List<Document> documentList) {
		for (Document document : documentList) {
			String currentSection=null;
			Map<String,String> sectionMap=new HashMap<String, String>();
			String text[] = document.getDocument_contain().replace("\"", "").split("\\\\n");
			String currentText ="";
			String WorkTyep=null;
			int i=1;
			for(String line:text) {	
				Matcher workTypematcher=worktype.matcher(line);
				if(workTypematcher.find()){
					if(WorkTyep!=null){
						sectionMap.put(currentSection,currentText);
						document.setSection(WorkTyep+"_"+i, sectionMap);
						sectionMap=new HashMap<String, String>();
						currentSection=null;
						currentText="";
						i++;
					}

					WorkTyep=workTypematcher.group(0);
					continue;
				}
				Matcher matcher=pattern.matcher(line);
				if(matcher.find()){	   
					if(currentSection!=null){
						sectionMap.put(currentSection,currentText);
					}
					currentSection=matcher.group(0);
					currentText=line.substring(matcher.end(0));
					continue;
				}
				if(currentSection!=null){
					currentText=currentText+" "+line;
				}
			}
			if(currentSection!=null){
				sectionMap.put(currentSection,currentText );
			}
			document.setSection(WorkTyep+"_"+i,sectionMap);		
		}
	}



	public static void main(String a[]){
		System.setProperty("bpl.home","/home/local/EZDI/vishal.d/workspace/backendpipeLine");
		SectionAnalysisFactroy sf=new SectionAnalysisFactroy();

		Document document=new Document();
		document.setDocument_contain("HPI \nDate/Time Seen by Provider 01/31/16 2350 \nPCP: none \nComplaint: nausea, vomiting \nSource of history: patient \nTiming - onset: hours (3) \nLocation of pain: upper abdomen \nRadiation of pain: none \nAssociated With: \nReports abdominal pain \nContext - history: chronic constipation \nContext - ingestion: \nDenies infectious exposure, Denies spoiled food \nExacerbated by: food, liquids \nAdditional hpi notes: \n24 yoM w/ hx of constipation presents to the ED c/o n/v with associated diffuse upper abd pain that \nbegan 3 hours PTA. Pt reports that he stopped smoking marijuana in December, and denies sick contacts \nor suspect food as his girlfriend ate the same food and currently has no sx. Pt reports chills but denies \ndiarrhea, urinary sx or any other associated sx. Pt also reports \" a more watery ejaculate than normal for \nthe past month.\" No radiation of pain, aggravating or relieving factors reported. \nPortions of this section were transcribed by Schlachtenhau,Brooke on 02/01/16 at 0351 \nReview of Systems \nConstitutional: \nReports: chills. \nRespiratory: \nDENIES: SOB. \nCardiovascular: \nDENIES: chest pain. \nGastrointestinal: \nnausea, vomiting, abdominal pain. DENIES: diarrhea, melena, hematochezia. \nGenitourinary: \nPage 1 of 7 \n \nDENIES: dysuria, hematuria. \nAll systems reviewed & negative except as marked. \nPortions of this section were transcribed by Schlachtenhau,Brooke on 02/01/16 at 0005 \nHistory-Medical/Family/Social \n)( Reviewed nursing notes: Yes (triage summary) \nAllergies: \nCoded Allergies: \nCephalosporins (UNKNOWN 01/31/16) cefaclor (From CECLOR) (UNKNOWN 01/31/16) loracarbef (From \nLORABID) (UNKNOWN 01/31/16) \nSocial history: \nDenies: alcohol, drugs, smoker. \nPortions of this section were transcribed by Schlachtenhau,Brooke on 02/01/16 at 0001 \nPhys Exam-Nausea/Vomit/Diarr \nGeneral: alert, well developed, well nourished \nHead/Eyes: normocephalic, PERRLA, EOMI, normal conjunctiva/sclera \nENT: moist mucous membranes \nNeck: supple/no men ingismus, full range of motion \nRespiratory/Chest: no distress (resp), normal breath sounds \nCardiovascular: regular rate and rhythm, normal heart sounds \nAbdomen: soft, no guarding/rebound, tenderness (upper abdomen), negative murphy's sign \nSkin: no rash, warm, dry \nNeurologic: alert, oriented X 3, normal speech, no motor deficits \nClinical Impression: \nPrimary Impression: Nausea & vomiting \nSecondary Impressions: Dyspepsia \n");
		List<Document> docList=new ArrayList<Document>();
		docList.add(document);
		Document document1=new Document();
		document1.setDocument_contain(" Joanne is a 79-year-old morbidly obese white female being admitted to Riverside Nursing Center from Mercy Health Partners in Muskegon. She was admitted to that facility on 04/24/2016 with diagnosis of acute congestive heart failure with acute hypoxic and hypercarbic respiratory failure. She has a known history of coronary artery disease with multiple stents. She also has COPD, has been ongoing smoker up to her hospitalization. She was brought to this facility for rehabilitation. Prior to her hospitalization, she lived with her daughter.");
		docList.add(document1);
		sf.analysisDocument(docList);
	}

}
