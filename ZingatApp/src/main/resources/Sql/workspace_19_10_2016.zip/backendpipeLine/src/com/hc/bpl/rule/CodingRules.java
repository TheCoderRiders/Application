package com.hc.bpl.rule;

public class CodingRules {

}
