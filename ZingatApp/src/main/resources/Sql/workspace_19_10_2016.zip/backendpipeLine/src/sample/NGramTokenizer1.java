package sample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class NGramTokenizer1 {
	private ArrayList<Token> output = new ArrayList<Token>();

	private List<Token> tokenList=new ArrayList<Token>();
	private Map<String,List<Token>> tokenMap=new HashMap<String, List<Token>>();
	private StringBuffer sb=new StringBuffer();
	public NGramTokenizer1( List<Token> tokenList ){
		this.tokenList = tokenList;
	}

	public static void main (String args[])
	{
		List<Token> tokenList=new ArrayList<Token>();
		Token t=new Token();
		t.setTokenString("w");
		t.setFlag(true);
		
		Token t1=new Token();
		t1.setTokenString("x");
		t1.setFlag(true);
		
		Token t2=new Token();
		t2.setTokenString("y");
		t2.setFlag(true);
		
		Token t3=new Token();
		t3.setTokenString("z");
		t3.setFlag(true);
		
		
		Token t4=new Token();
		t4.setTokenString("z");
		t4.setFlag(true);
		
		
		Token t5=new Token();
		t5.setTokenString("z");
		t5.setFlag(true);
		
		Token t6=new Token();
		t6.setTokenString("z");
		t6.setFlag(true);
		
		Token t7=new Token();
		t7.setTokenString("z");
		t7.setFlag(true);
		
		Token t8=new Token();
		t8.setTokenString("z");
		t8.setFlag(true);
		
		Token t9=new Token();
		t9.setTokenString("z");
		t9.setFlag(true);
		
		Token t10=new Token();
		t10.setTokenString("z");
		t10.setFlag(true);
		
		Token t11=new Token();
		t11.setTokenString("z");
		t11.setFlag(true);
		
		Token t12=new Token();
		t12.setTokenString("z");
		t12.setFlag(true);
		
		Token t13=new Token();
		t13.setTokenString("z");
		t13.setFlag(true);
		
		Token t14=new Token();
		t14.setTokenString("z");
		t14.setFlag(true);
		
		tokenList.add(t);
		tokenList.add(t1);
		tokenList.add(t2);
		tokenList.add(t3);
		tokenList.add(t4);
		tokenList.add(t5);
		tokenList.add(t6);
		tokenList.add(t7);		
		tokenList.add(t8);
		tokenList.add(t9);
		tokenList.add(t10);
		tokenList.add(t11);
		tokenList.add(t12);
		tokenList.add(t13);
		tokenList.add(t14);
		NGramTokenizer1 combobj= new NGramTokenizer1(tokenList);
		combobj.combine();
		combobj.display();
	}

	public void combine() { 
		combine( 0 ); 
	}
	public void display(){
		System.out.println("********************");
		for (String token :tokenMap.keySet()) {
			System.out.println(token);
		}
	}
	private void combine(int start ){
		for( int i = start; i < tokenList.size(); ++i ){
			
			if(output.size()==0){
				if(!tokenList.get(i).isFlag()){
					continue;
				}
			}
			sb.append(tokenList.get(i).getTokenString()+" ");
			System.out.println(sb);
			output.add(tokenList.get(i));
			tokenMap.put(sb.toString().trim(),	new ArrayList<Token>(output));
			if ( i < tokenList.size() ){
				
				combine( i + 1);
				
			}
			Token token =output.get( output.size() - 1 );
			sb.setLength(sb.length()-token.getTokenString().length()-1);
			output.remove( output.size() - 1 );
		
		}
	}
	
	
	
}
class Token{
	private String tokenString;
	private int offset;
	private int len;
	private boolean flag;

	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public String getTokenString() {
		return tokenString;
	}
	public void setTokenString(String tokenString) {
		this.tokenString = tokenString;
	}
	public int getOffset() {
		return offset;
	}
	public void setOffset(int offset) {
		this.offset = offset;
	}
	public int getLen() {
		return len;
	}
	public void setLen(int len) {
		this.len = len;
	}
	@Override
	public String toString() {
		return  tokenString;
	}
	
}