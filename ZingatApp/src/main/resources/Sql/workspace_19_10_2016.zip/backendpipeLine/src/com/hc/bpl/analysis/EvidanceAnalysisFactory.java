package com.hc.bpl.analysis;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hc.bpl.dto.AutoSuggestToken;
import com.hc.bpl.dto.Document;
import com.hc.bpl.dto.Postion;
import com.hc.bpl.dto.SectionAutoSuggestToken;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class EvidanceAnalysisFactory implements AnalysisFactory{
	private ConfigManager configManager;
	private  String  splitRegex;

	public EvidanceAnalysisFactory() {
		configManager=ConfigManager.getInstance();	
		splitRegex=configManager.getPropertie(Constants.SPLITREGEX);
	}

	@Override
	public void analysisDocument(List<Document> documentList) {
		for (Document document : documentList) {
			List<SectionAutoSuggestToken> listAutoSugestToken=document.getSectionAutoSuggest(); 
			String documetnHtmlText=document.getDocument_html_contain();
			for(SectionAutoSuggestToken sat:listAutoSugestToken){
				 Set<AutoSuggestToken> sugesstMap=sat.getCodes();
				String documentText=document.getDocument_contain();
				for (AutoSuggestToken autoSuggestToken:sugesstMap){
					String patternSting="";
					List<String> tokenList=autoSuggestToken.getToken();
					int i=0;
					if(tokenList!=null){
						for(String token:tokenList){
								if(token==null ||token.trim().isEmpty()){
									continue;
								}
						
							if(i==0){
								patternSting=token;	
							}
							else {
								patternSting=patternSting+"["+splitRegex+"]"+token;
							}	
							
							i++;
						}
						
						
								
						Pattern pattern=Pattern.compile(patternSting);
						Matcher matcher=pattern.matcher(documentText);
						List<Postion> postionList=new ArrayList<Postion>();
						if (matcher.find()) {
							Postion postion=new Postion();
							postion.setEnd(matcher.end());
							postion.setStart(matcher.start());
							postionList.add(postion);
							
							try{
								System.out.println(matcher.end());
								System.out.println(matcher.start());
								System.out.println(matcher.group(0));
								documetnHtmlText=documetnHtmlText.replaceAll(matcher.group(0), "<mark id=\""+autoSuggestToken.getCode()+"\">"+matcher.group(0)+"</mark>");
									
							}catch(Exception e){
								System.out.println("***********"+matcher.group(0));
							}
						}
					autoSuggestToken.setPostionList(postionList);
					}
				}
			
			}
			document.setDocument_html_contain(documetnHtmlText);
		}
	}

}
