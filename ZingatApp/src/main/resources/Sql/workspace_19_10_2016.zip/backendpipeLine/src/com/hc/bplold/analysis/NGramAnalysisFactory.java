package com.hc.bplold.analysis;



import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Spliterator;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.aliasi.util.Iterators;
import com.hc.bpl.analysis.AnalysisFactory;
import com.hc.bpl.analysis.SentenceAnalysisFactory;
import com.hc.bpl.dic.DictionaryLookup;
import com.hc.bpl.dto.AutoSuggestToken;
import com.hc.bpl.dto.Document;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class NGramAnalysisFactory implements AnalysisFactory {

	private ConfigManager configManager;
	private DictionaryLookup dictionaryLookup;
	private Pattern pattern;

	public NGramAnalysisFactory() {
		configManager=ConfigManager.getInstance();	
		pattern=Pattern.compile(configManager.getPropertie(Constants.SPLITREGEX));
		dictionaryLookup=new DictionaryLookup(configManager.getPropertie(Constants.SOLRURL), configManager.getPropertie(Constants.DEFAULT_SEARCH_FIELD));


	}

	@Override
	public void analysisDocument(List<Document> documentList) {
		for (Document document : documentList) {
			generateNgram(document);
		}
	}

	private  void generateNgram(Document document) {


		for(String line:document.getLine()){
			NGramTokenizer tokenizer=tokenizer(line);
			System.out.println(line);
			for (Iterator iterator = tokenizer.iterator(); iterator.hasNext();) {
				String ngram=iterator.next().toString();
				Set<AutoSuggestToken> suggestResult1=dictionaryLookup.lookup("\""+ngram+"\"",null);
				if(suggestResult1.size()>0){
					System.out.println(suggestResult1);	
				}
			}

		}



	}

	public  NGramTokenizer tokenizer(String line){
		Matcher match=pattern.matcher(line);
		int  start=0;
		List<Token> tokenList=new ArrayList<Token>();
		while(match.find()){
			insertToken(line.toCharArray(),start,match.start(0)-start,tokenList);
			start=match.end(0);
		}
		insertToken(line.toCharArray(),start,line.length()-start,tokenList);

		return new NGramTokenizer(tokenList,1,tokenList.size());
	}
	void  insertToken( char c[],int start,int len,List<Token> tokenList){
		String tokenString=new String( c, start, len).trim();
		if(!tokenString.isEmpty()){
			boolean isstart=false;
			boolean flag=dictionaryLookup.checkStartWorddictionry(tokenString);
			if(flag){
				isstart=flag;
			}else{
				flag=dictionaryLookup.checkWorddictionry(tokenString);
			}
			if(!flag){
				return;
			}
			Token token=new Token();
			token.setTokenString(tokenString);
			token.setLen(len);
			token.setOffset(start);
			token.setFlag(isstart);
			tokenList.add(token);

		}
	}

	class NGramTokenizer  implements Iterable<String> {
		private final int mMax;
		private List<Token> tokenList;
		private int NGram;
		private int pos = 0;
		public NGramTokenizer(List<Token> tokens, int min, int max) {
			tokenList = tokens;
			mMax = max;
			NGram = min;
		}
		public String nextToken() {
			if (NGram > mMax){
				return null;

			} 
			int endPos = pos + NGram - 1;
			if (endPos >=tokenList.size()) {
				++NGram;
				pos = 0;
				return nextToken();
			}
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < NGram; ++i) {
				if (i > 0) sb.append(' ');      
				sb.append(tokenList.get(pos + i).getTokenString());
			}           
			++pos;
			return sb.toString();
		}
		@Override
		public Iterator<String> iterator() {
			return new TokenIterator();
		}

		@Override
		public void forEach(Consumer<? super String> action) {
			// TODO Auto-generated method stub

		}
		@Override
		public Spliterator<String> spliterator() {
			// TODO Auto-generated method stub
			return null;
		}

		class TokenIterator extends Iterators.Buffered<String> {
			@Override
			public String bufferNext() {
				return nextToken();
			}
		}

	}

	public static void main(String a[]) throws JsonGenerationException, JsonMappingException, IOException{
		System.setProperty("bpl.home","/home/local/EZDI/vishal.d/workspace/backendpipeLine");
		NGramAnalysisFactory nl=new NGramAnalysisFactory();
		SentenceAnalysisFactory sd=new SentenceAnalysisFactory();
		Document document=new Document();
		document.setDocument_contain("he had Typhoid pneumonia,Typhoid arthritis, unspecified site");
		Map<String,String> sectionMap=new HashMap<String, String>();
		sectionMap.put("data", "he had Typhoid pneumonia,Typhoid arthritis, unspecified site");
		document.setSection("data",sectionMap);
		List<Document> docList=new ArrayList<Document>();
		docList.add(document);
		sd.analysisDocument(docList);
		nl.analysisDocument(docList);
		ObjectMapper mapper = new ObjectMapper();
		ByteArrayOutputStream s=new ByteArrayOutputStream();
		mapper.writeValue(s, docList);
		System.out.println(new String(s.toByteArray()));
		s.flush();
		s.reset();
		s.close();

	}


}

class Token{
	private String tokenString;
	private int offset;
	private int len;
	private boolean flag;

	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public String getTokenString() {
		return tokenString;
	}
	public void setTokenString(String tokenString) {
		this.tokenString = tokenString;
	}
	public int getOffset() {
		return offset;
	}
	public void setOffset(int offset) {
		this.offset = offset;
	}
	public int getLen() {
		return len;
	}
	public void setLen(int len) {
		this.len = len;
	}
}
