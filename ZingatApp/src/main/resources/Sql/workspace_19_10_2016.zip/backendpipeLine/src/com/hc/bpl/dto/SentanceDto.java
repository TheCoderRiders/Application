package com.hc.bpl.dto;

import java.util.List;

public class SentanceDto {
	
private String line;
private List<String> token;

}
