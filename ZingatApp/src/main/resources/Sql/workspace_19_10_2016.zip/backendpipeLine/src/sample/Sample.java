package sample;
import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;
import java.util.function.Consumer;



import com.aliasi.util.Iterators;

public class Sample {

	static String[] data=new String("data vishal domale").split("\\s+");
     static int len;
     static int start=0;
     static int temp=0;
     static int max_token=1;

     public static void main(String a[]){
    	 data=":  1.      End-stage renal disease.".split("\\s+|,|\\[|\\]|\\{|\\}|\\-|:|\\.|\"|\\(|\\)|\\|'|/");
    	 for (String string : data) {
			System.out.println(string);
		}
     }
     
     //	public static void main(String a[]){
//		len=data.length;
//		String token=null;
//		 while ((token=nextToken())!=null) {
//			System.out.println(token);
//			
//		}
//	}

	public static String  nextToken(){
		if(max_token>=len){
			return null;
		} 
		if((start+max_token)>len){
			max_token++;
			start=0;
			nextToken();
		}
		StringBuilder sb = new StringBuilder();
		for(int i=0;i<max_token;i++){
			if (i > 0) sb.append(' ');      
			sb.append(data[start+i]);
		}
		//System.out.println(sb);
		start++;
		return sb.toString();
		
	}
	
	class NGramTokenizer  implements Iterable<String> {
		private final int mMax;
		private List<String> tokenList;
		private int NGram;
		private int pos = 0;
		public NGramTokenizer(List<String> tokens, int min, int max) {
			tokenList = tokens;
			mMax = max;
			NGram = min;
		}
		public String nextToken() {
			if (NGram > mMax){
				return null;

			} 
			int endPos = pos + NGram - 1;
			if (endPos >=tokenList.size()) {
				++NGram;
				pos = 0;
				return nextToken();
			}
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < NGram; ++i) {
				if (i > 0) sb.append(' ');      
				sb.append(tokenList.get(pos + i));
			}           
			++pos;
			return sb.toString();
		}
		@Override
		public Iterator<String> iterator() {
			return new TokenIterator();
		}

		@Override
		public void forEach(Consumer<? super String> action) {
			// TODO Auto-generated method stub

		}
		@Override
		public Spliterator<String> spliterator() {
			// TODO Auto-generated method stub
			return null;
		}

		class TokenIterator extends Iterators.Buffered<String> {
			@Override
			public String bufferNext() {
				return nextToken();
			}
		}

	}
	

}



