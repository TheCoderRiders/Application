package com.hc.bpl.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Document {

	private int id;
	private String document_id;
	private String document_contain;
	private String document_html_contain;
	private String document_name;
	private Map<String ,Map<String ,String>> workType = new HashMap<String,Map<String,String>>();
	private List<SectionAutoSuggestToken> sectionAutoSuggest=new ArrayList<SectionAutoSuggestToken>();
	private List<SectionAutoSuggestToken> maySectionAutoSuggest=new ArrayList<SectionAutoSuggestToken>();
	private List<String> line=new ArrayList<String>();
	private Map<String ,Map<String ,List<String>>> lines=new HashMap<String, Map<String,List<String>>>();
	
	
	
	
	public Map<String, Map<String, List<String>>> getLines() {
		return lines;
	}
	public void setLines(String WorkType, Map<String, List<String>> sectionLines) {
		lines.put(WorkType, sectionLines);
	}


	public Map<String, Map<String, String>> getSection() {
		return workType;
	}

	public void setSection(String worktypename ,Map<String ,String> section) {
		workType.put(worktypename, section);
	}
	public String getDocument_html_contain() {
		return document_html_contain;
	}
	public void setDocument_html_contain(String document_html_contain) {
		this.document_html_contain = document_html_contain;
	}
	public List<String> getLine() {
		return line;
	}
	public void setLine(List<String> line) {
		this.line = line;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDocument_id() {
		return document_id;
	}
	public void setDocument_id(String document_id) {
		this.document_id = document_id;
	}
	public String getDocument_contain() {
		return document_contain;
	}
	public void setDocument_contain(String document_contain) {
		this.document_contain = document_contain;
	}
	public String getDocument_name() {
		return document_name;
	}
	public void setDocument_name(String document_name) {
		this.document_name = document_name;
	}
	public List<SectionAutoSuggestToken> getSectionAutoSuggest() {
		return sectionAutoSuggest;
	}
	public void setSectionAutoSuggest(SectionAutoSuggestToken e) {
		this.sectionAutoSuggest.add(e);
	}


	public List<SectionAutoSuggestToken> getMaySectionAutoSuggest() {
		return maySectionAutoSuggest;
	}
	public void setMaySectionAutoSuggest(SectionAutoSuggestToken maySectionAutoSuggest) {
		this.maySectionAutoSuggest.add(maySectionAutoSuggest);
	}
	
}
