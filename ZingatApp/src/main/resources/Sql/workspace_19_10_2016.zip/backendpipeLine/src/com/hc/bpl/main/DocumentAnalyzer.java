package com.hc.bpl.main;



import java.sql.Connection;
import java.sql.Timestamp;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.log4j.Logger;
import com.hc.bpl.doa.DBConnection;
import com.hc.bpl.doa.DocumentDao;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class DocumentAnalyzer {
	private ConfigManager configManager;
	final static Logger logger = Logger.getLogger(DocumentAnalyzer.class);
	private int fileCountPerThread=10;
	public DocumentAnalyzer() {
		configManager=ConfigManager.getInstance();	
	}

	public void run() {	
		ExecutorService executorService = Executors.newFixedThreadPool(10);	
		try{
			Timestamp timestamp=new Timestamp(new Date().getTime());
			int len =getCount(new Timestamp(new Date().getTime()));
			logger.info("Total Number of  files :- "+len);
			logger.info("Total Thread of  files :- "+(len%fileCountPerThread==0?len/fileCountPerThread:len/fileCountPerThread+1));
			for (int i = 0; i < len - fileCountPerThread + 1; i += fileCountPerThread){
				
				DocumentProcessor doc=new DocumentProcessor(i,fileCountPerThread,timestamp);
				executorService.submit(doc);
			}
			if (len % fileCountPerThread != 0){
				DocumentProcessor doc=new DocumentProcessor(len - len % fileCountPerThread,fileCountPerThread,timestamp);
				executorService.submit(doc);
			}
			executorService.shutdown();
			while (!executorService.isTerminated()) {
			}
		}catch(Exception e){
			e.printStackTrace();
		}


	}

	public int getCount(Timestamp timestamp) throws Exception{
		DocumentDao documentDao=null;
		try{
			String query=configManager.getPropertie(Constants.SELECTCOUNTQUERY);
			Connection conn=DBConnection.getConnection(configManager);
			documentDao=new DocumentDao(conn); 
			return documentDao.getCount(query.replaceAll("__document_parsed_datetime__", timestamp.toString()));
		}catch(Exception e){
			throw e;
		}

	}


}
