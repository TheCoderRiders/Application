package com.hc.bpl.doa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class DBConnection {

	public static Connection getConnection(ConfigManager configManager){
		Connection conn=null;
		if(conn==null){
			try {
				String driverName=configManager.getPropertie(Constants.DRIVER_NAME);
				String dbUrl=configManager.getPropertie(Constants.MYSQL_URL);
				String dbUserName=configManager.getPropertie(Constants.MYSQL_USERNAME);
				String dbPassword=configManager.getPropertie(Constants.MYSQL_PASSWORD);
				Class.forName(driverName);
				conn=DriverManager.getConnection(dbUrl, dbUserName, dbPassword);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return conn;		

	}




}
