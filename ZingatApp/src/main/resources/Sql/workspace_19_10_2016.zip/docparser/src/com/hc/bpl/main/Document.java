package com.hc.bpl.main;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;




import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.hc.bpl.doa.DBConnection;
import com.hc.bpl.doa.DocumentDao;
import com.hc.bpl.doc.processor.DocumetParser;
import com.hc.bpl.doc.processor.PDFDocumentParser;
import com.hc.bpl.doc.processor.Parser;
import com.hc.bpl.dto.DocumentDto;
import com.hc.bpl.se.SolrClient;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class Document  extends Thread{
	private Parser documentParser=null;
	private File [] files;
	private ConfigManager configManager;
	private Connection conn;
	private SolrClient solrClient;
	private int commit_count=10;
	private String ERROR="error";
	private String SUCCESS="success";
	private String successDir;
	private String errorDir;

	final static Logger logger = Logger.getLogger(Document.class);

	public Document(File [] files) {
		configManager=ConfigManager.getInstance();
		successDir=	configManager.getPropertie(Constants.OUTPUTDIRECTORY);	
		errorDir=	configManager.getPropertie(Constants.ERRORDIRECTORY);	
		this.files=files;
		init();
	}
	private void init(){
		
		solrClient =new SolrClient(configManager.getPropertie(Constants.SOLRURL));
		try{
			documentParser=new DocumetParser();
			commit_count=Integer.parseInt(configManager.getPropertie(Constants.COMMIT_COUNT));
		}catch (Exception e) {
			commit_count=10;
			e.printStackTrace();
		}

	}

	@Override
	public void run() {
		try{
			String threadName=Thread.currentThread().getName();
			logger.info("Start thread" + threadName);
			logger.info("No of  Files : - " + files.length);
			conn=DBConnection.getConnection(configManager);
			DocumentDao documentDao=new DocumentDao(conn);
			int i=0;
			for (File file : files) {
				try {
					logger.info(file.getName()+" this file Processing By :- " + threadName);
					i++;
					DocumentDto documentDto=new DocumentDto();
					documentParser.parseDcoument(file,documentDto);
					documentDao.insertDocument(documentDto);
					solrClient.submitDocument(documentDto);
					if(i%commit_count==0){
						solrClient.commit();
					}
					logger.info(file.getName()+" this file Processed By :- " + threadName);
					moveFile(file, SUCCESS);
				} catch (Exception e) {
					moveFile(file, ERROR);
					e.printStackTrace();
				}
			}
			if(i%commit_count!=0){
				solrClient.commit();
			}
			logger.info("End thread" +threadName);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(conn!=null){
				try {
					conn.close();
					solrClient.CloseSolrClient();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private void moveFile(File file,String Status){
		File dest=null;
		if(Status.equals(ERROR)){
			dest=new File(errorDir+"/"+file.getName());
		}
		if(Status.equals(SUCCESS)){
			dest=new File(successDir+"/"+file.getName());
		}
		try {
			FileUtils.moveFile(file, dest);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
