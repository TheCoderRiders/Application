package com.hc.bpl.doc.processor;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Map;

import javax.swing.JEditorPane;
import javax.swing.text.BadLocationException;
import com.lowagie.text.Document;
import javax.swing.text.EditorKit;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.rtf.RTFEditorKit;

import com.hc.bpl.dto.DocumentDto;
import com.lowagie.text.rtf.parser.RtfParser;

public class Sample{


	public static void main(String [] arg)  {
		Document document = new Document();
		RtfParser parser = new RtfParser(null);
		try {
			document.open();
			parser.convertRtfDocument(new FileInputStream("/home/local/EZDI/vishal.d/workspace/docparser/output/bursztynise-420-[1501-777777-2459]-[04302016]-[135349]-17@1234473524M.doc"), document);

			System.out.println(document.getHtmlStyleClass());

			document.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


	public static String rtfToHtml(Reader rtf) throws IOException {
		JEditorPane p = new JEditorPane();
		p.setContentType("text/rtf");

		RTFEditorKit kitRtf = (RTFEditorKit) p.getEditorKitForContentType("text/rtf");

		try {
			kitRtf.read(rtf, p.getDocument(), 0);


			HTMLEditorKit  kitHtml =new HTMLEditorKit();
			Writer writer = new StringWriter();
		//	Document dt= p.getDocument();

			kitHtml.write(writer, p.getDocument(), 0, p.getDocument().getLength());

			return writer.toString();
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		return null;
	}
}
