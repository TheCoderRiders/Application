package com.hc.bpl.main;



import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class DocumentManager {

	private String inputDir;
	private String outDir;
	private ConfigManager configManager;
	final static Logger logger = Logger.getLogger(DocumentManager.class);
	private int fileCountPerThread=10;
	public DocumentManager() {
		configManager=ConfigManager.getInstance();
		inputDir=configManager.getPropertie(Constants.INPUTDIRECTORY);
		outDir=	configManager.getPropertie(Constants.OUTPUTDIRECTORY);	
		 try{
			 fileCountPerThread=Integer.parseInt(configManager.getPropertie(Constants.FILEPERTHREAD));
		 }catch(Exception e){
			 logger.error("Configuration Error in "+Constants.FILEPERTHREAD);
			 fileCountPerThread=10;
		 }
		logger.info("Input Directory "+inputDir);
		logger.info("Out Directory "+outDir);
	}

	public void run(){	
		ExecutorService executorService = Executors.newFixedThreadPool(10);	
		File [] files=getFiels(inputDir);
		if(files==null){
			logger.error("Wrong In InputDirectory "+inputDir);
			return;
		}
		
		try{
			
			int len = files.length;
			logger.info("Total Number of  files :- "+len);
			logger.info("Total Tread of  files :- "+(len%fileCountPerThread==0?len/fileCountPerThread:len/fileCountPerThread+1));
			for (int i = 0; i < len - fileCountPerThread + 1; i += fileCountPerThread){
				File fileChunk[] = Arrays.copyOfRange(files, i, i + fileCountPerThread);
				Document doc=new Document(fileChunk);
				executorService.submit(doc);
			}
			if (len % fileCountPerThread != 0){
				File  fileChunk[] = Arrays.copyOfRange(files, len - len % fileCountPerThread, len);
				Document doc=new Document(fileChunk);
				executorService.submit(doc);
			}
			executorService.shutdown();
			while (!executorService.isTerminated()) {
			}
		}catch(Exception e){
			e.printStackTrace();
		}


	}

	private File[] getFiels(String inputDirctroy){

		File fl = new File(inputDirctroy);
		File[] files = fl.listFiles(); 
		return files;

	}



}
