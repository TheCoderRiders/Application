package com.hc.bpl.se;

import java.io.IOException;

import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.common.SolrInputDocument;

import com.hc.bpl.dto.DocumentDto;

public class SolrClient {


	public SolrClient(String solrUrl) {
		server=getSolrClient(solrUrl);
	}
	private  org.apache.solr.client.solrj.SolrClient server;
	public  org.apache.solr.client.solrj.SolrClient getSolrClient(String solrUrl){
		if(server==null){
			server = new HttpSolrClient(solrUrl);
		}
		return server;	
	}


	public void submitDocument(DocumentDto documentDto ) throws SolrServerException, IOException{
		try {
			SolrInputDocument doc=new SolrInputDocument();
			doc.setField("id", documentDto.getDocument_id());
			doc.setField("document_id", documentDto.getDocument_id());
			doc.setField("document_name", documentDto.getDocument_name());
			doc.setField("document_path", documentDto.getDocument_path());
			doc.setField("document_current_status", documentDto.getDocument_current_status());
			doc.setField("document_current_status_id", documentDto.getDocument_current_status_id());
			doc.setField("document_contents", documentDto.getDocument_contents());
			server.add(doc);
		} catch (SolrServerException e) {
			
			e.printStackTrace();
			throw e;
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
	}


	public void CloseSolrClient(){
		if(server!=null){
			try {
				server.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	} 
	public void commit(){
		try {
			server.commit();
		} catch (SolrServerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
