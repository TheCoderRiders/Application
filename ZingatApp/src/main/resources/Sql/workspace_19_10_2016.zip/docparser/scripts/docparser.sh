#!/bin/sh

SCRIPT=$(readlink -f "$0")
SCRIPT=$(dirname "$SCRIPT")
BD=$(dirname "$SCRIPT")

echo $BD
CLASSPATH=$(find "$BD/lib/" -name '*.jar' -printf '%p:' | sed 's/:$//')

java -cp "$CLASSPATH" com.hc.bpl.main.Driver $BD
