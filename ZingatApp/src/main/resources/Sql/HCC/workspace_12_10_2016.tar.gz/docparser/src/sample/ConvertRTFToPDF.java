package sample;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.html.HtmlWriter;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.rtf.parser.RtfParser;
import com.lowagie.text.rtf.table.RtfRow;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;

public class ConvertRTFToPDF {


	public static void main(String[] args) throws Exception {
//		String inputFile = "/home/local/EZDI/vishal.d/workspace/docparser/output/bursztynise-420-[1501-777777-2459]-[04302016]-[135349]-17@1234473524M.doc";
//		String outputFile = "/home/local/EZDI/vishal.d/sample_converted.html";
//
//		// create a new document
//		Document document = new Document();
//
//		try {
//			document.open();
//			HtmlWriter writer = HtmlWriter.getInstance(document, new FileOutputStream(outputFile));
//			RtfParser parser = new RtfParser(null);
//			parser.convertRtfDocument(new FileInputStream(inputFile), document);
//			document.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		} 
		
		
		  Metadata metadata = new Metadata();
		  File file = new File("/home/local/EZDI/vishal.d/workspace/docparser/output/10.PDF");
		  FileInputStream input = new FileInputStream(file);
		  org.apache.tika.parser.Parser parser = new AutoDetectParser();
		    StringWriter sw = new StringWriter();
		    SAXTransformerFactory factory = (SAXTransformerFactory)
		             SAXTransformerFactory.newInstance();
		    TransformerHandler handler = factory.newTransformerHandler();
		    handler.getTransformer().setOutputProperty(OutputKeys.METHOD, "xml");
		    handler.getTransformer().setOutputProperty(OutputKeys.INDENT, "yes");
		    handler.setResult(new StreamResult(sw));

		    parser.parse(input, handler, metadata, new ParseContext());

		    String xhtml = sw.toString();
		    System.out.println(xhtml);
	}

}
