package sample;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;

import javax.swing.JEditorPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.EditorKit;
import javax.swing.text.StyledDocument;
import javax.swing.text.html.HTMLEditorKit;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.hwpf.HWPFDocumentCore;
import org.apache.poi.hwpf.converter.WordToHtmlConverter;
import org.apache.poi.hwpf.converter.WordToHtmlUtils;
import org.w3c.dom.Document;

public class DocSample {
	
	
	
	public static void main(String a[]) throws Exception{
		
		
		String s=rtfToHtml(new FileReader("/home/local/EZDI/vishal.d/sample_File/raymondr-NOCH/raymondr-17164-00@80029A-[05022016]-[081911]-[RAYM_SOAP_RAYM0090].doc"));

		
	}

	
	public static String rtfToHtml(Reader rtf) throws IOException {
		   JEditorPane p = new JEditorPane();
		   p.setContentType("text/rtf");
		   EditorKit kitRtf = p.getEditorKitForContentType("text/rtf");
		   try {
		      kitRtf.read(rtf, p.getDocument(), 0);
		      kitRtf = null;
		      HTMLEditorKit kitHtml = new HTMLEditorKit();
		      Writer writer = new StringWriter();
		      kitHtml.write(writer, p.getDocument(), 0, p.getDocument().getLength());
		      return writer.toString();
		   } catch (BadLocationException e) {
		      e.printStackTrace();
		   }
		   return null;
		}
}
