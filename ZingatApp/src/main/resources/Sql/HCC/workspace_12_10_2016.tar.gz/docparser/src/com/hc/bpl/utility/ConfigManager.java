package com.hc.bpl.utility;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;




public class ConfigManager {
	private Map<String ,String> configmap =new HashMap<String, String>();
	private static ConfigManager configManager;

	public static final String DOCPARSER_HOME=System.getProperty(Constants.DOCPARSER_HOME);


	private ConfigManager(){
		try {
			configmap=readConfig();
		} catch (IOException e) {
			System.out.println("Error in configuration file");
			e.printStackTrace();
		}
	}

	public static ConfigManager getInstance(){
		if(configManager==null){
			configManager=new ConfigManager();
		}
		return configManager;
	}

	private  Map<String,String> readConfig() throws IOException {
		BufferedReader bufferedReader=null;
		String line;
		try {
			bufferedReader=new BufferedReader(new FileReader(DOCPARSER_HOME+"/conf/docparser.properties"));
			Map<String,String> configmap=new HashMap<String, String>();
			while((line=bufferedReader.readLine())!=null){
				if(line.trim().isEmpty()){
					continue;
				}
				if(line.startsWith("#")){
					continue;
				}
				String token[]=line.split("=");
				configmap.put(token[0].trim(),token[1].trim());
			}
			return configmap;
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(bufferedReader!=null){
				bufferedReader.close();
			}
		}

	}

	public String getPropertie(String key){
		if(configmap!=null){
			return configmap.get(key);
		}
		return null;
	}
	

}
