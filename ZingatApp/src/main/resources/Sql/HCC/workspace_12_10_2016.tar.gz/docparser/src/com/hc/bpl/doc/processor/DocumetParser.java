package com.hc.bpl.doc.processor;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.tika.Tika;

import com.hc.bpl.dto.DocumentDto;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class DocumetParser implements Parser{

	private PDFDocumentParser pdfDocumentParser;
	private RTFParser rtfParser;
	private Tika tika;
	private static final String APP_RTF="application/rtf";
	private static final String APP_PDF="application/pdf";
	private ConfigManager configManager;
	public DocumetParser(){
		configManager=ConfigManager.getInstance();
		tika = new Tika();
		rtfParser=new RTFParser();
		try {
			pdfDocumentParser=new  PDFDocumentParser(configManager.getPropertie(Constants.SECTIONPATTERN));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void parseDcoument(File FileName, DocumentDto dto) throws Exception {


		String filetype = tika.detect(FileName);
		StringBuffer plainText=new StringBuffer();
		dto.setDocument_id(FileName.getName());
		dto.setDocument_name(FileName.getName());
		dto.setDocument_path(FileName.getAbsolutePath());
		dto.setParseDate_date(new Timestamp(new Date().getTime()));
		dto.setReceived_date(new Timestamp(FileName.lastModified()));
		String html_text="";
		if(filetype.equalsIgnoreCase(APP_RTF)){
			html_text=rtfParser.parse(FileName, null);
		}
		if(filetype.equalsIgnoreCase(APP_PDF))  {
			html_text=pdfDocumentParser.parse(FileName,plainText);
		}
	    html_text=html_text.replaceAll("\\\n", "");
	    html_text=html_text.replace("'", "\\\'");
		dto.setDocument_contents(html_text);
		dto.setDocument_plain_contents(plainText.toString());
	    
	}



}
