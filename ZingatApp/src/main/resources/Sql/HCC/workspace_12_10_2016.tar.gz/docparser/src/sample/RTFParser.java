package sample;

import java.io.IOException;
import java.io.InputStream;
import java.util.Set;

import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.rtf.RTFEditorKit;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.sax.XHTMLContentHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

/**
 * RTF parser
 */
public class RTFParser implements Parser {

	public void parse(InputStream stream, ContentHandler handler,Metadata metadata, ParseContext context)throws IOException, SAXException, TikaException {
		try {
			DefaultStyledDocument sd = new DefaultStyledDocument();
			new RTFEditorKit().read(stream, sd, 0);

			XHTMLContentHandler xhtml =
					new XHTMLContentHandler(handler, metadata);
			xhtml.startDocument();
			xhtml.element("p", sd.getText(0, sd.getLength()));
			xhtml.endDocument();
		} catch (BadLocationException e) {
			throw new TikaException("Error parsing an RTF document", e);
		} catch (InternalError e) {
			throw new TikaException(
					"Internal error parsing an RTF document, see TIKA-282", e);
		}
	}

	/**
	 * @deprecated This method will be removed in Apache Tika 1.0.
	 */
	public void parse(
			InputStream stream, ContentHandler handler, Metadata metadata)
					throws IOException, SAXException, TikaException {
		parse(stream, handler, metadata, new ParseContext());
	}

	@Override
	public Set<MediaType> getSupportedTypes(ParseContext context) {
		// TODO Auto-generated method stub
		return null;
	}

}