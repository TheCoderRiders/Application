package com.hc.bpl.main;

import org.apache.log4j.PropertyConfigurator;

import com.hc.bpl.utility.Constants;

public class Driver {
	public static void main(String args[]){	
		String log4jConfigFile = args[0]+"/log/log4j.properties";
		PropertyConfigurator.configure(log4jConfigFile);
		System.setProperty(Constants.DOCPARSER_HOME,args[0]);
		DocumentManager documentManager=new DocumentManager();
		documentManager.run();
	}
}
