package com.hc.bpl.doc.processor;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.io.RandomAccessFile;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class PDFManager {


	private PDFText2HTML pdfStripper;
	private PDDocument pdDoc ;
	private COSDocument cosDoc ;
	private Pattern pattern;
	public PDFManager(String patternString) throws IOException {
		pattern=Pattern.compile(patternString,Pattern.CASE_INSENSITIVE);
		pdfStripper= new PDFText2HTML();

	}
	public String getText(File file,StringBuffer plainText) throws IOException
	{
		String Text="";
		this.pdDoc = null;
		this.cosDoc = null;
		PDFParser  parser = new PDFParser(new RandomAccessFile(file,"r"));
		parser.parse();
		cosDoc = parser.getDocument();
		pdDoc = new PDDocument(cosDoc);
		pdDoc.getNumberOfPages();
		pdfStripper.setStartPage(1);
		pdfStripper.setEndPage(pdDoc.getNumberOfPages());
		Text = pdfStripper.getText(pdDoc,plainText);
		return Text;
	}

}
