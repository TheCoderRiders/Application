package test;

import java.io.FileInputStream;

import javax.swing.text.DefaultStyledDocument;



public class DocSample {
	
	
	
	public static void main(String a[]) throws Exception{
		DefaultStyledDocument sd = new DefaultStyledDocument();
		  RTFReader rdr = new RTFReader(sd);
          rdr.readFromStream(new FileInputStream("/home/local/EZDI/vishal.d/sample_File/raymondr-NOCH/raymondr-17164-00@80029A-[05022016]-[081911]-[RAYM_SOAP_RAYM0090].doc"));
          rdr.close();
          System.out.println(sd.getText(0, sd.getLength()));
         
		
		//String s=rtfToHtml(new FileReader("/home/local/EZDI/vishal.d/sample_File/raymondr-NOCH/raymondr-17164-00@80029A-[05022016]-[081911]-[RAYM_SOAP_RAYM0090].doc"));

		
	}

	
//	public static String rtfToHtml(Reader rtf) throws IOException {
//		   JEditorPane p = new JEditorPane();
//		   p.setContentType("text/rtf");
//		   EditorKit kitRtf = p.getEditorKitForContentType("text/rtf");
//		   try {
//		      kitRtf.read(rtf, p.getDocument(), 0);
//		      kitRtf = null;
//		      EditorKit kitHtml = p.getEditorKitForContentType("text/html");
//		      Writer writer = new StringWriter();
//		      kitHtml.write(writer, p.getDocument(), 0, p.getDocument().getLength());
//		      return writer.toString();
//		   } catch (BadLocationException e) {
//		      e.printStackTrace();
//		   }
//		   return null;
//		}
}
