package com.hc.bpl.dto;

import java.sql.Timestamp;
import java.util.Map;

public class DocumentDto {

	private String document_id;
	private String document_name;
	private String document_path;
	private String document_contents;
	private String document_current_status="";
	private int document_current_status_id=111;
	private Timestamp received_date;
	private Timestamp parseDate_date;
	private String document_plain_contents;

	public String getDocument_plain_contents() {
		return document_plain_contents;
	}
	public void setDocument_plain_contents(String document_plain_contents) {
		this.document_plain_contents = document_plain_contents;
	}
	public Timestamp getReceived_date() {
		return received_date;
	}
	public void setReceived_date(Timestamp received_date) {
		this.received_date = received_date;
	}
	public Timestamp getParseDate_date() {
		return parseDate_date;
	}
	public void setParseDate_date(Timestamp parseDate_date) {
		this.parseDate_date = parseDate_date;
	}
	public String getDocument_id() {
		return document_id;
	}
	public void setDocument_id(String document_id) {
		this.document_id = document_id;
	}
	public String getDocument_name() {
		return document_name;
	}
	public void setDocument_name(String document_name) {
		this.document_name = document_name;
	}
	public String getDocument_path() {
		return document_path;
	}
	public void setDocument_path(String document_path) {
		this.document_path = document_path;
	}
	public String getDocument_contents() {
		return document_contents;
	}
	public void setDocument_contents(String document_contents) {
		this.document_contents = document_contents;
	}
	public String getDocument_current_status() {
		return document_current_status;
	}
	public void setDocument_current_status(String document_current_status) {
		this.document_current_status = document_current_status;
	}
	public int getDocument_current_status_id() {
		return document_current_status_id;
	}
	public void setDocument_current_status_id(int document_current_status_id) {
		this.document_current_status_id = document_current_status_id;
	}

}
