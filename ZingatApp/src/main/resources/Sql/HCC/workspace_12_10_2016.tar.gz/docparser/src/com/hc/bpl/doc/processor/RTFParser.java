package com.hc.bpl.doc.processor;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Map;

import javax.swing.JEditorPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.EditorKit;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.rtf.RTFEditorKit;

import com.hc.bpl.dto.DocumentDto;

public class RTFParser{

	
	public String  parse(File FileName, Map<String, String> sectionMap) throws Exception {
		
		return rtfToHtml(new FileReader(FileName));
		
	}

	
	public static String rtfToHtml(Reader rtf) throws IOException {
		   JEditorPane p = new JEditorPane();
		   p.setContentType("text/rtf");
		  
		   RTFEditorKit kitRtf = (RTFEditorKit) p.getEditorKitForContentType("text/rtf");
		   try {
		      kitRtf.read(rtf, p.getDocument(), 0);
		      kitRtf = null;
		      HTMLEditorKit kitHtml = new HTMLEditorKit();
		      Writer writer = new StringWriter();
		      kitHtml.write(writer, p.getDocument(), 0, p.getDocument().getLength());
		      return writer.toString();
		   } catch (BadLocationException e) {
		      e.printStackTrace();
		   }
		   return null;
		}
}
