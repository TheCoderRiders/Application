package com.hc.bpl.doc.processor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
import java.sql.Timestamp;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.pdf.PDFParser;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import com.hc.bpl.dto.DocumentDto;

public class PDFDocumentParser {
	private PDFManager pDFManager;

	public PDFDocumentParser(String patternString) throws IOException{
		try {

			pDFManager=new PDFManager(patternString);
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
	}
	public String   parse(File file, StringBuffer plainText) throws IOException, SAXException, TikaException{
		try {

			String text=pDFManager.getText(file,plainText);
			return text;
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		} 

	}


}
