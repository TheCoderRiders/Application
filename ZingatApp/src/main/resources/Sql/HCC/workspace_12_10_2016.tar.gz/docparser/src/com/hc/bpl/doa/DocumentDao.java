package com.hc.bpl.doa;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.codehaus.jackson.map.ObjectMapper;

import com.hc.bpl.dto.DocumentDto;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class DocumentDao {

	private String documentInsertQuery;
	private Connection conn;
	private String selectIDquery;
	private ObjectMapper mapper = null;
	private	ByteArrayOutputStream s=null;
	public DocumentDao(Connection conn) {
		ConfigManager configManager=ConfigManager.getInstance();	
		documentInsertQuery=configManager.getPropertie(Constants.DOCUMENTINSERTQUERY);
		selectIDquery=configManager.getPropertie(Constants.SELECTIDQUERY);
		mapper = new ObjectMapper();
		s=new ByteArrayOutputStream();
		this.conn=conn;
	}


	public  void insertDocument(DocumentDto documentDto) throws Exception	{
		PreparedStatement prepareStatement=null;
		try {
			prepareStatement =conn.prepareStatement(documentInsertQuery);
			prepareStatement.setString(1, documentDto.getDocument_id());
			prepareStatement.setString(2, documentDto.getDocument_name());
			prepareStatement.setString(3, documentDto.getDocument_path());
			prepareStatement.setString(4, documentDto.getDocument_contents());
			prepareStatement.setString(5, documentDto.getDocument_current_status());
			prepareStatement.setInt(6, documentDto.getDocument_current_status_id());	
			prepareStatement.setString(7, "parser");
			prepareStatement.setString(8, "parser");
			prepareStatement.setTimestamp(9, documentDto.getReceived_date());
			prepareStatement.setTimestamp(10, documentDto.getParseDate_date());
		 	prepareStatement.setString(11, getJson(documentDto.getDocument_plain_contents()));
			prepareStatement .executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if(prepareStatement!=null){
				try {
					prepareStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
					throw e;
				}
			}

		}

	}
	public String getJson(Object t) throws Exception{
		String jsonString=null;
		try{
			mapper.writeValue( s,t);
			s.flush();
			jsonString=new String(s.toByteArray());
			s.flush();
			s.reset();
			return jsonString;
		}catch(Exception e){	
			throw e;
		}
	}
	public void close(){
		if(s!=null){
			try {
				s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
