package sample;



import java.io.File;

import net.sourceforge.tess4j.*;

public class TesseractExample {

	public static void main(String[] args) {
		File fl = new File("/home/local/EZDI/vishal.d/workspace/backendpipeLine/output/");
		Tesseract tesseract = Tesseract.getInstance(); 
		tesseract.setDatapath("/usr/share/tesseract-ocr/"); 
		File[] files = fl.listFiles(); 
		for(File file:files){
			System.out.println("********************");
			try {
				String text= tesseract.doOCR(file);
				System.out.println(text);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("********************");
		}
	}
}
