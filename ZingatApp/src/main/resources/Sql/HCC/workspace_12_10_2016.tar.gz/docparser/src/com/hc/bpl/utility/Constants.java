package com.hc.bpl.utility;

public class Constants {
	
	public static final String DOCPARSER_HOME="docparser.home";

	public static final String SOLRURL="solr_url";
	public static final String COMMIT_COUNT="commit_count";
	public static final String DEFAULT_SEARCH_FIELD="default_search_field";
	public static final String SOLR_FIELD="solr_field";

	public static final String DRIVER_NAME="driver_name";
	public static final String MYSQL_URL="mysqlUrl";
	public static final String MYSQL_USERNAME="mysqlUserName";
	public static final String MYSQL_PASSWORD="mysqlPassword";

	public static final String INPUTDIRECTORY="inputDirectory";
	public static final String OUTPUTDIRECTORY="outputDirectory";
	public static final String DOCUMENTINSERTQUERY = "documentInsertQuery";
	public static final String SELECTIDQUERY = "selectIdQuery";

	public static final String ERRORDIRECTORY = "errorDirectory";
	
	
	public static final String FILEPERTHREAD="filecountperthread";

	public static final String SECTIONPATTERN ="SectionPattern";





}
