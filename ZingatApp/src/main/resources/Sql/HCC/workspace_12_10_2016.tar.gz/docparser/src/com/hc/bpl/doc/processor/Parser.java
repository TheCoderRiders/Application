package com.hc.bpl.doc.processor;

import java.io.File;

import com.hc.bpl.dto.DocumentDto;



public interface Parser {

	public void  parseDcoument(File FileName,DocumentDto dto) throws Exception;

}
