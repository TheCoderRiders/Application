package com.hc.bplold.analysis;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import com.hc.bpl.analysis.AnalysisFactory;
import com.hc.bpl.dto.Document;

import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.process.DocumentPreprocessor;

public class SentanceAnalysisFactory implements AnalysisFactory {
	
	
   public SentanceAnalysisFactory(){
		
	}

	@Override
	public void analysisDocument(List<Document> documentList) {
		
		for (Document document : documentList) {
	//		System.out.println("*************");
			DocumentPreprocessor dp = new DocumentPreprocessor( new StringReader(document.getDocument_contain()));
		      for (List<HasWord> sentence : dp) {
		       for(HasWord word:sentence){
		    	   System.out.println(word +" " +((CoreLabel)word).endPosition());
		       }
		      }
		}
		 
	}
	
	public static void main(String a[]){
		
		SentanceAnalysisFactory sf=new SentanceAnalysisFactory();
		Document document=new Document();
		document.setDocument_contain(" Joanne is a 79-year-old morbidly obese white female being admitted to Riverside Nursing Center from Mercy Health Partners in Muskegon. She was admitted to that facility on 04/24/2016 with diagnosis of acute congestive heart failure with acute hypoxic and hypercarbic respiratory failure. She has a known history of coronary artery disease with multiple stents. She also has COPD, has been ongoing smoker up to her hospitalization. She was brought to this facility for rehabilitation. Prior to her hospitalization, she lived with her daughter.");
		List<Document> docList=new ArrayList<Document>();
		docList.add(document);
		Document document1=new Document();
		document1.setDocument_contain(" Joanne is a 79-year-old morbidly obese white female being admitted to Riverside Nursing Center from Mercy Health Partners in Muskegon. She was admitted to that facility on 04/24/2016 with diagnosis of acute congestive heart failure with acute hypoxic and hypercarbic respiratory failure. She has a known history of coronary artery disease with multiple stents. She also has COPD, has been ongoing smoker up to her hospitalization. She was brought to this facility for rehabilitation. Prior to her hospitalization, she lived with her daughter.");
		docList.add(document1);
		sf.analysisDocument(docList);
	}

}
