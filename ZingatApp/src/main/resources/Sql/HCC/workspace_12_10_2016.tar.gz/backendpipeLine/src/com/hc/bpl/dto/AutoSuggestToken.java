package com.hc.bpl.dto;


import java.util.List;

public class AutoSuggestToken {
	private String code;
	private String desc;
	private List<Postion> postionList;
	private List<String> token;

	
	private String type;
	
	

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public List<Postion> getPostionList() {
		return postionList;
	}
	public void setPostionList(List<Postion> postionList) {
		this.postionList = postionList;
	}
	public List<String> getToken() {
		return token;
	}
	public void setToken(List<String> token) {
		this.token = token;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "[ "+code+"|"+desc+"|"+type+"]";
	}
	@Override
	public int hashCode() {
		
		return 123;
	}
	@Override
	public boolean equals(Object obj) {
		AutoSuggestToken ast=(AutoSuggestToken)obj;
		return this.code.equalsIgnoreCase(ast.getCode());
	} 

	
}
