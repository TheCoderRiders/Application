package com.hc.bplold.analysis;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.hc.bpl.analysis.AnalysisFactory;
import com.hc.bpl.analysis.EvidanceAnalysisFactory;
import com.hc.bpl.dic.DictionaryLookup;
import com.hc.bpl.dto.AutoSuggestToken;
import com.hc.bpl.dto.Document;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class PhraseAnalysisFactory implements AnalysisFactory {

	private ConfigManager configManager;
	private DictionaryLookup dictionaryLookup;
	private  String  splitRegex;
	private final String SPACE="\\ ";
	private final String STAR="*";
	private final String DOUBLEQUOTE="\"";
	private final String BACKSLASH="\\";
	private final String EMPTYSTRING="";

	public PhraseAnalysisFactory() {
		configManager=ConfigManager.getInstance();	
		splitRegex=configManager.getPropertie(Constants.SPLITREGEX);
		dictionaryLookup=new DictionaryLookup(configManager.getPropertie(Constants.SOLRURL), configManager.getPropertie(Constants.DEFAULT_SEARCH_FIELD));
	}
	@Override
	public void analysisDocument(List<Document> documentList) {
		for (Document document : documentList) {
			Set<AutoSuggestToken> suggestResult=new HashSet<AutoSuggestToken>();
			generatePhrase(document.getDocument_contain(),suggestResult);
	//		document.setAutoSuggestMap(null, suggestResult);
		}
	}
	private  void generatePhrase(String text,Set<AutoSuggestToken> suggestMap) {
		
		String[] tokens = text.split(splitRegex);
		for(int k=0; k<tokens.length-1; k++){
			String nGramString=EMPTYSTRING;
			int start=k;
				Set<AutoSuggestToken> prevsuggestResult=null;
				Set<AutoSuggestToken> suggestResult=null;
			int lastStage=0;
			for(int j=start; j<tokens.length; j++){
				String token=tokens[j].trim();
				if(token.isEmpty()){
					continue;
				}
				if(j==k){
					nGramString=token+SPACE ;
				}else{
					nGramString=nGramString+token+SPACE;
				}
				suggestResult=dictionaryLookup.lookup(nGramString+STAR,null);
				String query=phraseQuery(nGramString);
				if(suggestResult.size()==0){
					suggestResult=dictionaryLookup.lookup(query,null);
					if (suggestResult.size()!=0) {						 
						suggestMap.addAll(suggestResult);
						String[] evtoken=Arrays.copyOfRange(tokens,k,j+1);
						List<String> evList=Arrays.asList(evtoken);
//						for(String key:suggestResult.keySet()){
//							AutoSuggestToken ast=suggestResult.get(key);
//							ast.setToken(evList);
//						}
						k=j;
						
					}else{
						if(prevsuggestResult!=null){
							suggestMap.addAll(prevsuggestResult);
							String[] evtoken=Arrays.copyOfRange(tokens,k,lastStage+1);
							List<String> evList=Arrays.asList(evtoken);
//							for(String key:suggestResult.keySet()){
//								AutoSuggestToken ast=suggestResult.get(key);
//								ast.setToken(evList);
//							}
							k=lastStage;
						}
					}
					break;
				}else{
					Set<AutoSuggestToken> suggestResult1=dictionaryLookup.lookup(query,null);
					if(suggestResult1.size()!=0){
						prevsuggestResult=suggestResult1;
						lastStage=j;
					}

				}

			}	
		}
	}


	private String phraseQuery(String s){
		String query=DOUBLEQUOTE+s.replace(BACKSLASH,EMPTYSTRING).trim()+DOUBLEQUOTE;
		return query;
	}



	public static void main(String a[]) throws JsonGenerationException, JsonMappingException, IOException{
		System.setProperty("bpl.home","/home/local/EZDI/vishal.d/workspace/backendpipeLine");
		PhraseAnalysisFactory nl=new PhraseAnalysisFactory();
		EvidanceAnalysisFactory eaf=new EvidanceAnalysisFactory();
		Document document=new Document();
		document.setDocument_contain("he had Typhoid pneumonia,Typhoid arthritis, unspecified site");
		List<Document> docList=new ArrayList<Document>();
		docList.add(document);
		nl.analysisDocument(docList);
		eaf.analysisDocument(docList);
		ObjectMapper mapper = new ObjectMapper();
		ByteArrayOutputStream s=new ByteArrayOutputStream();
		mapper.writeValue(s, docList);
		System.out.println(new String(s.toByteArray()));
		s.flush();
		s.reset();
		s.close();

	}

}
