package com.hc.bpl.analysis;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.solr.client.solrj.SolrServerException;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;

import com.hc.bpl.dic.CombineCodeLookup;
import com.hc.bpl.dic.DictionaryLookup;
import com.hc.bpl.dto.AutoSuggestToken;
import com.hc.bpl.dto.Document;
import com.hc.bpl.dto.SectionAutoSuggestToken;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class NewPhraseAnalysisFactory implements AnalysisFactory {

	private ConfigManager configManager;
	private  String  splitRegex;
	private final String SPACE="\\ ";
	private final String STAR="*";
	private final String DOUBLEQUOTE="\"";
	private final String BACKSLASH="\\";
	private final String EMPTYSTRING="";
	private DictionaryLookup dictionaryLookup;
	private static Set<String> setDontCodeSection=new HashSet<>();
	private Pattern nigativePattern_middel;
	private Pattern nigativePattern_start;
	private Pattern pattern;
	private final static String OR=" OR ";
	private CombineCodeLookup combineCodeLookup;

	static{
		setDontCodeSection.add("FAMILY HISTORY");
	}

	public NewPhraseAnalysisFactory() throws IOException, SolrServerException {
		configManager=ConfigManager.getInstance();	
		splitRegex=configManager.getPropertie(Constants.SPLITREGEX);
		dictionaryLookup=new DictionaryLookup(configManager.getPropertie(Constants.SOLRURL), configManager.getPropertie(Constants.DEFAULT_SEARCH_FIELD));
		pattern=Pattern.compile(configManager.getPropertie(Constants.SPLITREGEX));
		nigativePattern_middel=Pattern.compile(configManager.getPropertie(Constants.NEGATIVEPATTERN_MIDDEL));;
		nigativePattern_start=Pattern.compile(configManager.getPropertie(Constants.NEGATIVEPATTERN_START));
		combineCodeLookup=new CombineCodeLookup(configManager.getPropertie(Constants.COMBINESOLRURL));

	}

	@Override
	public void analysisDocument(List<Document> documentList) {
		for (Document document : documentList) {
			Map<String ,Map<String ,List<String>>> lines=document.getLines();
			Map<List<String>,Set<String>>  evidence=new HashMap<List<String>, Set<String>>();
			for(String workType:lines.keySet()){
				System.out.println("**********"+workType+"****************");
				Map<String ,List<String>> sectionLines=lines.get(workType);
				Set<AutoSuggestToken> suggestResult=new HashSet<AutoSuggestToken>();
				for(String section:sectionLines.keySet()){
					if(!setDontCodeSection.contains(section)){
						for(String s:sectionLines.get(section)){
							generatePhrase(s,suggestResult,evidence);
						}
					}
				}
				Set<AutoSuggestToken> suggestCode=new HashSet<AutoSuggestToken>();
				Set<AutoSuggestToken> mayBeSuggestCode=new HashSet<AutoSuggestToken>();
				markCombineCode(suggestResult,suggestCode,mayBeSuggestCode);
				
				if(mayBeSuggestCode.size()!=0){
					SectionAutoSuggestToken sat=new SectionAutoSuggestToken();
					sat.setSectionName(workType);
					sat.setCodes(mayBeSuggestCode);
					document.setMaySectionAutoSuggest(sat);
				}
				if(suggestCode.size()!=0){
					SectionAutoSuggestToken sat1=new SectionAutoSuggestToken();
					sat1.setSectionName(workType);
					sat1.setCodes(suggestCode);	
					document.setSectionAutoSuggest(sat1);
				}
				
			}
			
			document.setEvidenceMap(evidence);
		}
	}
	private  void generatePhrase(String line, Set<AutoSuggestToken> suggestedSet,Map<List<String>,Set<String>>  evidence) {
		Matcher matcher = nigativePattern_middel.matcher(line);
		boolean negativeFlag=false;
		boolean startWithnegative=false;
		int negativeEviednce=-1;
		List<AutoSuggestToken> codes=new ArrayList<AutoSuggestToken>();

		Matcher matcher1=nigativePattern_start.matcher(line);
		if(matcher1.find()){
			negativeFlag=true;
			startWithnegative=true;
		}	
		else if(matcher.find()){
			negativeFlag=true;
			negativeEviednce=matcher.start();
		}
		String[] tokens= createToken(line);
		for(int k=0; k<tokens.length; k++){
			String nGramString=EMPTYSTRING;
			int start=k;
			int temp=k;
			Set<AutoSuggestToken> prevsuggestResult=null;
			int j=start;
			for(; j<tokens.length; j++){
				String token=tokens[j].trim();
				if(token.isEmpty()){
					continue;
				}
				if(j==k){
					nGramString=token+SPACE ;
				}else{
					nGramString=nGramString+token+SPACE;
				}
				Set<AutoSuggestToken> suggestResult=dictionaryLookup.lookup(nGramString+STAR,Constants.EVIDENCE);
				if(suggestResult.size()!=0){
					String query=phraseQuery(nGramString);
					suggestResult=dictionaryLookup.lookup(query.toLowerCase(),Constants.EVIDENCE);
					if(suggestResult.size()!=0){
						prevsuggestResult=suggestResult;
						temp=j;
					}
					continue;
				}
				else{
					break;
				}
			}		
			String query=phraseQuery(nGramString);
			Set<AutoSuggestToken> suggestResult=dictionaryLookup.lookup(query.toLowerCase(),Constants.EVIDENCE);
			if(suggestResult.size()>0){
				prevsuggestResult=suggestResult;
				temp=j;
			}
			if(prevsuggestResult!=null){
				if(temp>=tokens.length){
					temp=tokens.length-1;
				}
				String[] evtoken=Arrays.copyOfRange(tokens,k,temp+1);
				List<String> evList=Arrays.asList(evtoken);
				k=temp;
				addTokenList(prevsuggestResult,evList,evidence);
				suggestedSet.addAll(prevsuggestResult);
				if(negativeFlag){
					codes.addAll(prevsuggestResult);
				}

			}
		}

		if(codes.size()!=0){
			if(startWithnegative==true){
				for(AutoSuggestToken ast:codes){
					ast.setType(Constants.NEGATIVE);
				}
			}
			else if (negativeEviednce!=-1){
				int j=0;
				for (AutoSuggestToken autoSuggestToken:codes){
					List<String> tokenList=autoSuggestToken.getToken();
					Pattern pattern=getPattern(tokenList);
					Matcher matcher3=pattern.matcher(line);
					int start=-1;
					while (matcher3.find()) {
						start=matcher3.start();
					}
					if(start!=-1 && start>negativeEviednce){
						break;
					}
					j++;
				}
				for(;j<codes.size();j++){
					AutoSuggestToken autoSuggestToken=codes.get(j);
					autoSuggestToken.setType(Constants.NEGATIVE);
				}


			}
		}
	}
	
	
	private void addEvidence(Map<List<String>,Set<String>>  evidence,List<String> tokenList,String code){		
		Set<String> codeSet= evidence.get(tokenList);
		if(codeSet==null){
			codeSet=new HashSet<String>();
			codeSet.add(code);
			evidence.put(tokenList, codeSet);
		}
		else{
			codeSet.add(code);
		}
		
	}
	private Pattern getPattern(List<String> tokenList){
		int i=0;
		String patternSting="";
		Pattern pattern=null;
		if(tokenList!=null){
			for(String token:tokenList){

				if(token==null ||token.trim().isEmpty()){
					continue;
				}

				if(i==0){
					patternSting=token;	
				}
				else {
					patternSting=patternSting+"["+splitRegex+"]"+token;
				}	

				i++;
			}
			pattern=Pattern.compile(patternSting);
		}
		return pattern;
	}
	private String[] createToken(String line){
		Matcher match=pattern.matcher(line);
		int  start=0;
		List<String> tokenList=new ArrayList<String>();
		while(match.find()){
			insertToken(line.toCharArray(),start,match.start(0)-start,tokenList);
			start=match.end(0);
		}
		insertToken(line.toCharArray(),start,line.length()-start,tokenList);
		String[] stockArr = new String[tokenList.size()];
		return tokenList.toArray(stockArr);
	}

	private void  insertToken( char c[],int start,int len,List<String> tokenList){
		String tokenString=new String( c, start, len).trim();
		if(!tokenString.isEmpty()){
			tokenList.add(tokenString);
		}
	}
	private void addTokenList(Set<AutoSuggestToken> suggestResult,List<String> token,Map<List<String>,Set<String>>  evidence){
		for(AutoSuggestToken ast:suggestResult){
			ast.setToken(token);
			addEvidence(evidence, token, ast.getCode());
		}

	}
	private String phraseQuery(String s){
		String query=DOUBLEQUOTE+s.replace(BACKSLASH,EMPTYSTRING).trim()+DOUBLEQUOTE;
		return query;
	}


	private void markCombineCode(Set<AutoSuggestToken> suggestedSet,Set<AutoSuggestToken> suggestCode,Set<AutoSuggestToken> mayBesuggestCode){
		StringBuffer queryBuffer=new StringBuffer();

		int i=0;
		for(AutoSuggestToken ast:suggestedSet){
			if(ast.getType()==Constants.NEGATIVE){
				mayBesuggestCode.add(ast);
				continue;
			}
			if(i==0){

				queryBuffer.append(ast.getCode()+" ");
				i++;
				continue;
			}
			i++;
			queryBuffer.append(OR+ast.getCode());
		}
		Set<String> responseCodeSet=new TreeSet<String>();
		Set<String> deleteCodeSet=new TreeSet<String>();
		combineCodeLookup.lookup(queryBuffer.toString(), responseCodeSet, deleteCodeSet);

		i=0;
		StringBuffer addedQueryBuffer=new StringBuffer();
		for(String code:responseCodeSet){
			if(i==0){
				addedQueryBuffer.append("code_id:"+code+" ");
				i++;
				continue;
			}
			i++;
			addedQueryBuffer.append(OR+"code_id:"+code);

		}	
		Set<AutoSuggestToken> suggestResult1=dictionaryLookup.lookup(addedQueryBuffer.toString(),Constants.COMBINE);
		suggestCode.addAll(suggestResult1);
		for(AutoSuggestToken ast:suggestedSet){
			if(deleteCodeSet.contains(ast.getCode())){
				ast.setType(Constants.COMBINE_REJECT);
				mayBesuggestCode.add(ast);
			}
			else if(ast.getType()!=Constants.NEGATIVE) {
				suggestCode.add(ast);
			}
		}

	}


	public static void main(String a[]) throws JsonGenerationException, JsonMappingException, IOException, SolrServerException{
		System.setProperty("bpl.home","/home/local/EZDI/vishal.d/workspace/backendpipeLine");
		NewPhraseAnalysisFactory nl=new NewPhraseAnalysisFactory();
		EvidanceAnalysisFactory eaf=new EvidanceAnalysisFactory();
		Document document=new Document();
		document.setDocument_contain("he had Typhoid pneumonia,Typhoid arthritis, unspecified site");
		List<String> line=new ArrayList<String>();
		line.add("he had Typhoid pneumonia,Typhoid arthritis, unspecified site");
		Map<String,List<String>> sectionMap=new HashMap<String, List<String>>();
		sectionMap.put("code",line );
		document.setLines("WorkType", sectionMap);
		List<Document> docList=new ArrayList<Document>();
		docList.add(document);
		nl.analysisDocument(docList);
		eaf.analysisDocument(docList);


	}

}
