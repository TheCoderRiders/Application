package com.hc.bpl.dto;


import java.util.Set;

public class SectionAutoSuggestToken {
	private  String sectionName;
	private  Set<AutoSuggestToken> codes;

	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	public  Set<AutoSuggestToken> getCodes() {
		return codes;
	}
	public void setCodes( Set<AutoSuggestToken> codes) {
		this.codes = codes;
	}
}
