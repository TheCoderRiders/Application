package com.hc.bpl.analysis;

import java.util.List;

import com.hc.bpl.dto.Document;

public interface AnalysisFactory {
	public void analysisDocument(List<Document> documentList);
}
