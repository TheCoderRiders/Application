package com.hc.bpl.dic;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;

public class HccSolrClientUtil {

	
	
	public  static SolrClient getSolrClient(String url) throws SolrServerException {
		SolrClient server = new HttpSolrClient(url);
		return server;
	}
}
