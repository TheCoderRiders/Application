package com.hc.bplold.analysis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hc.bpl.analysis.AnalysisFactory;
import com.hc.bpl.dic.DictionaryLookup;
import com.hc.bpl.dto.AutoSuggestToken;
import com.hc.bpl.dto.Document;
import com.hc.bpl.dto.SectionAutoSuggestToken;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class CombineCodeAnalysisFactroy implements AnalysisFactory{
	private DictionaryLookup dictionaryLookup;
	private ConfigManager configManager;
	public static  String BPL_HOME=System.getProperty("bpl.home");
	private Map <String,List<String>> combineMap;
	private String CODE_ID="code_id";
	private Map<String,String> codesMap=new HashMap<String, String>();
	public CombineCodeAnalysisFactroy() {
		configManager=ConfigManager.getInstance();
		dictionaryLookup=new DictionaryLookup(configManager.getPropertie(Constants.SOLRURL), configManager.getPropertie(Constants.DEFAULT_SEARCH_FIELD));
		combineMap=read(codesMap);
	}

	@Override
	public void analysisDocument(List<Document> documentList) {
		for(Document document:documentList){
			Set<String> codes=new HashSet<String>();
			Map <String,List<String>> combineMap=new HashMap<String, List<String>>();
			for(SectionAutoSuggestToken sast:document.getSectionAutoSuggest()){
				for(AutoSuggestToken s:sast.getCodes()){
					codes.add(s.getCode());
					List<String> list=this.combineMap.get(s.getCode());
					combineMap.put(s.getCode(),list);
				}
			}
			
			for(String code:combineMap.keySet()){
				for(String combineWithcode:combineMap.get(code)){
					if(codes.contains(combineWithcode)){
						System.out.println(codesMap.get(code+","+combineWithcode));
					}
				}
			}
		}
	}


	private Map <String,List<String>> read(Map<String,String> codes) {
		BufferedReader bufferedReader=null;
		Map <String,List<String>> combineMap=new HashMap<String,List<String>>();
		String line;
		try {
			bufferedReader=new BufferedReader(new FileReader(BPL_HOME+"/conf/CombineFile.csv"));
			while((line=bufferedReader.readLine())!=null){
				if(line.trim().isEmpty()){
					continue;
				}
				if(line.startsWith("#")){
					continue;
				}
				String token[]=line.split("\t");
				codes.put(token[0].replace("\"",""), token[1].replace("\"",""));
				String firstToken[]=token[0].split(",");
				add(combineMap,firstToken[0].replace("\"",""), firstToken[1].replace("\"",""));
			}
		} catch (IOException e) {
			e.printStackTrace();

		}finally{
			if(bufferedReader!=null){
				try {
					bufferedReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return combineMap;
	}

	public void add(Map <String,List<String>> combineMap,String token1,String token2){
		List<String> list=combineMap.get(token1);
		if(list!=null){
			list.add(token2);
		}
		else{
			list=new ArrayList<String>();
			list.add(token2);
			combineMap.put(token1, list);
		}

	}


	public static void main(String a[]) throws IOException{
		System.setProperty("bpl.home","/home/local/EZDI/vishal.d/workspace/backendpipeLine");
		BPL_HOME=System.getProperty("bpl.home");
		CombineCodeAnalysisFactroy ccaf=new CombineCodeAnalysisFactroy();
		System.out.println(ccaf.combineMap);
	}


}
