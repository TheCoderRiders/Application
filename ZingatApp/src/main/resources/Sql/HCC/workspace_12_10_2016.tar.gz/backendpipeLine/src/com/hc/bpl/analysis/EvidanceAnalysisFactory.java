package com.hc.bpl.analysis;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.hc.bpl.dto.Document;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class EvidanceAnalysisFactory implements AnalysisFactory{
	private ConfigManager configManager;
	private  String  splitRegex;

	public EvidanceAnalysisFactory() {
		configManager=ConfigManager.getInstance();	
		splitRegex=configManager.getPropertie(Constants.SPLITREGEX);
	} 

	@Override
	public void analysisDocument(List<Document> documentList) {
		for (Document document : documentList) {
			String documetnHtmlText=document.getDocument_html_contain();
				Map<List<String>,Set<String>> evidence=document.getEvidenceMap();
				String documentText=document.getDocument_contain();
				for (List<String> tokenList:evidence.keySet()){
					String patternSting="";
					int i=0; 
					if(tokenList!=null) {
						for(String token:tokenList){
							if(i==0){
								patternSting=token;	
							}
							else {
								patternSting=patternSting+"["+splitRegex+"]"+token;
							}	
							
							i++;
						}
						
						String codeStr=makeCodeString(evidence.get(tokenList));
			     		Pattern pattern=Pattern.compile(patternSting);
						Matcher matcher=pattern.matcher(documentText);
						if (matcher.find()) {						
							int end=matcher.end();
							int start=matcher.start();
							try{
								documetnHtmlText=documetnHtmlText.replaceAll(matcher.group(0), "<mark class=\""+codeStr+"\">"+matcher.group(0)+"</mark>");
									
							}catch(Exception e){
								System.out.println("***********"+matcher.group(0));
							}
						}
					
					}
				}
			
			
			document.setDocument_html_contain(documetnHtmlText);
		}
	}
	
	
	
	private String makeCodeString(Set<String> codes ){
		
		String str="";
		for(String code:codes){
			str=str+" "+code;
		}
		return str.trim();
	}

}
