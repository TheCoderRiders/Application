package com.hc.bpl.main;

import org.apache.log4j.PropertyConfigurator;

public class Driver {	
	public static void main(String args[]){
		System.setProperty("bpl.home","/home/local/EZDI/vishal.d/workspace/backendpipeLine");
		String log4jConfigFile = "/home/local/EZDI/vishal.d/workspace/backendpipeLine"+"/log/log4j.properties";
		PropertyConfigurator.configure(log4jConfigFile);
		new DocumentAnalyzer().run();
	}
}
