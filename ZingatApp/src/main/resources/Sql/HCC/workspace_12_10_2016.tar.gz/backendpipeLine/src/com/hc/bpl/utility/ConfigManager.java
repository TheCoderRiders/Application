package com.hc.bpl.utility;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;




public class ConfigManager {
	private Map<String ,String> configmap =new HashMap<String, String>();
	private static ConfigManager configManager;
	public static final String BPL_HOME=System.getProperty("bpl.home");


	private ConfigManager(){
		try {
			configmap=readConfig();
			configmap.put(Constants.SECTIONPATTERN, readSectionNames());
			configmap.put(Constants.WORKTYPEPATTERN, readWorkTypeNames());
			String [] regex=readNegative();
			configmap.put(Constants.NEGATIVEPATTERN_MIDDEL,regex[0]);
			configmap.put(Constants.NEGATIVEPATTERN_START, regex[1]);
		} catch (IOException e) {
			System.out.println("Error in configuration file");
			e.printStackTrace();
		}
	}

	private String readWorkTypeNames() throws IOException {
		BufferedReader bufferedReader=null;
		StringBuffer sb=new StringBuffer();
		String line;
		sb.append("^(");
		try {
			bufferedReader=new BufferedReader(new FileReader(BPL_HOME+"/conf/worktype.txt"));
			int i=0;
			while((line=bufferedReader.readLine())!=null){
				if(line.trim().isEmpty()){
					continue;
				}
				if(line.startsWith("#")){
					continue;
				}
				if(i!=0){
					sb.append("|\\s*"+line.trim()+"\\s*");
				}else{
					sb.append("\\s*"+line.trim()+"\\s*");
				}
				
				i++;
			}
			sb.append(")");
		return sb.toString();
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(bufferedReader!=null){
				bufferedReader.close();
			}
		}
		
	}
	
	private String[] readNegative() throws IOException{
        String StringArray[]=new String[2];
		BufferedReader bufferedReader=null;
		StringBuffer sb1=new StringBuffer();
		StringBuffer sb2=new StringBuffer();
		sb2.append("^(");
		String line;
		try {
			bufferedReader=new BufferedReader(new FileReader(BPL_HOME+"/conf/nigative.txt"));
			int i=0;
			while((line=bufferedReader.readLine())!=null){
				if(line.trim().isEmpty()){
					continue;
				}
				if(line.startsWith("#")){
					continue;
				}
				if(i!=0){
					sb1.append("|\\s+"+line.trim()+"\\s+");
					sb2.append("|"+line.trim()+"\\s+");
				}else{
					sb1.append("\\s+"+line.trim()+"\\s+");
					sb2.append(line.trim()+"\\s+");
				}	
				i++;
			}
			sb2.append(")");
			StringArray[0]=sb1.toString();
			StringArray[1]=sb2.toString();
		return StringArray;
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(bufferedReader!=null){
				bufferedReader.close();
			}
		}
		
	
	}

	public static ConfigManager getInstance(){
		if(configManager==null){
			configManager=new ConfigManager();
		}
		return configManager;
	}

	private  Map<String,String> readConfig() throws IOException {
		BufferedReader bufferedReader=null;
		String line;
		try {
			bufferedReader=new BufferedReader(new FileReader(BPL_HOME+"/conf/bpl.properties"));
			Map<String,String> configmap=new HashMap<String, String>();
			while((line=bufferedReader.readLine())!=null){
				if(line.trim().isEmpty()){
					continue;
				}
				if(line.startsWith("#")){
					continue;
				}
				String key=line.substring(0, line.indexOf("=")).trim();
				String value=line.substring(line.indexOf("=")+1, line.length()).trim();
				configmap.put(key,value);
			}
			return configmap;
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(bufferedReader!=null){
				bufferedReader.close();
			}
		}

	}
	
	private String readSectionNames() throws IOException {
		BufferedReader bufferedReader=null;
		StringBuffer sb=new StringBuffer();
		String line;
		sb.append("^(");
		try {
			bufferedReader=new BufferedReader(new FileReader(BPL_HOME+"/conf/section.txt"));
			int i=0;
			while((line=bufferedReader.readLine())!=null){
				if(line.trim().isEmpty()){
					continue;
				}
				if(line.startsWith("#")){
					continue;
				}
				if(i!=0){
					sb.append("|\\s*"+line.trim()+"\\s*");
				}else{
					sb.append("\\s*"+line.trim()+"\\s*");
				}
				
				i++;
			}
			sb.append(")");
		return sb.toString();
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(bufferedReader!=null){
				bufferedReader.close();
			}
		}

	}

	public String getPropertie(String key){
		if(configmap!=null){
			return configmap.get(key);
		}
		return null;
	}

}
