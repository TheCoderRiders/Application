package com.hc.bpl.dic;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.analysis.core.KeywordAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.PhraseQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.WildcardQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import com.hc.bpl.dto.AutoSuggestToken;



public class LuceneDictonary {

    private QueryParser qp;
	private static Directory indexDir;
	private IndexSearcher indexSearcher;

	public LuceneDictonary(String dirPath) throws IOException {
		try {
			indexDir=FSDirectory.open(new File(dirPath).toPath());
			IndexReader ir=DirectoryReader.open(indexDir);
			indexSearcher=new IndexSearcher(ir);
			qp=new QueryParser("search_field", new KeywordAnalyzer());
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
		
	}

	public boolean searchWildQuery(String queryString) {
		boolean flag=false;
		Term term = new Term("search_field", queryString.toLowerCase());
		Query query = new WildcardQuery(term);
		TopDocs hits=null;
		try {
		
			hits = indexSearcher.search(query,1);
			if(hits.totalHits>=1){
				flag=true;
			} 
		} catch (IOException e) {
			e.printStackTrace();
		}		
		return flag;
	}
	public Map<String,AutoSuggestToken>  searchQuery(String queryString){
		 Query query=null;
		try {
			query = qp.parse(queryString.toLowerCase());
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Map<String,AutoSuggestToken> responseList=new HashMap<String,AutoSuggestToken>();
		if(query!=null){
			try {
				TopDocs hits = indexSearcher.search(query,20);
				for(ScoreDoc scoreDoc : hits.scoreDocs) {
					Document doc =   indexSearcher.doc(scoreDoc.doc); 
					AutoSuggestToken autoSuggestToken=new AutoSuggestToken();
					autoSuggestToken.setCode(doc.get("code_id").toString());
					autoSuggestToken.setDesc(doc.get("code_description").toString());
					responseList.put(doc.get("code_id").toString(),autoSuggestToken);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return responseList;

	}
	public void close(){
		if(indexDir!=null){
			try {
				indexDir.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static void main(String a[]){
		try {
			LuceneDictonary ld=new LuceneDictonary("/home/local/EZDI/vishal.d/dic/data/index");
//ld.retrive();
			System.out.println(ld.searchQuery("\"Typhoid pneumonia\""));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
