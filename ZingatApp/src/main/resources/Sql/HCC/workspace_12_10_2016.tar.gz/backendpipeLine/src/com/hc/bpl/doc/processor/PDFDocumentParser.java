package com.hc.bpl.doc.processor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.pdf.PDFParser;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

public class PDFDocumentParser {
	PDFParser pdfparser;
	public PDFDocumentParser(){
		pdfparser = new PDFParser();
	}


	public static void main(String a[]) throws IOException, SAXException, TikaException{
		InputStream is=null;
		PDFDocumentParser pdfdp=new PDFDocumentParser();
		try {
			is = new FileInputStream(new File("/home/local/EZDI/vishal.d/workspace/docparser/input/1.pdf"));
			ContentHandler contenthandler = new BodyContentHandler();
			Metadata metadata = new Metadata();
			pdfdp.pdfparser.parse(is, contenthandler, metadata, new ParseContext());
			System.out.println( contenthandler.toString());
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		} catch (SAXException e) {		
			e.printStackTrace();
			throw e;
		} catch (TikaException e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(is!=null){
				is.close();
			}
		}

	}

}
