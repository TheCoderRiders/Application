package com.hc.bpl.dic;

import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;


public class CombineCodeLookup {

	private SolrClient server;
	
	  //TO DO
	  // private String filterQuery="icd_09_10: \"ICD10\"";

	public CombineCodeLookup(String url) throws SolrServerException{
		server=HccSolrClientUtil.getSolrClient(url);
	}

	
	public void lookup(String queryString,Set<String> responseCodeSet,Set<String> combineCodeSet){
		SolrQuery query=new SolrQuery();
		query.setQuery(queryString);
		query.setFields("*","score");
		try {
			QueryResponse qr=server.query(query);
			SolrDocumentList sdl=qr.getResults();
			for (SolrDocument solrDocument : sdl) {
				Float score=Float.parseFloat(solrDocument.getFieldValue("score").toString());
				if(score<2){
					break;
				}
				if(solrDocument.getFieldValues("suggested_codes")!=null){
					addAll(responseCodeSet,solrDocument.getFieldValues("suggested_codes"));
				}
				if(solrDocument.getFieldValues("deleted_codes")!=null){
					addAll(combineCodeSet,solrDocument.getFieldValues("deleted_codes"));
				}
			
			}

		} catch (SolrServerException | IOException e) {
					e.printStackTrace();
		}
	}
	
	
	void addAll(Set<String> set,Collection<Object> col){
		for(Object e:col){
			set.add(((String) e).toUpperCase());
		}
	}
	
	
	public static void main(String a[]) throws SolrServerException{
		CombineCodeLookup CCL=new CombineCodeLookup("http://192.168.17.88:8983/solr/hcc_combination_codes");
		Set<String> responseCodeSet=new TreeSet<String>();
		Set<String> combineCodeSet=new TreeSet<String>();
		CCL.lookup("N18.1 OR I10 OR N18.2",responseCodeSet,combineCodeSet);
		System.out.println(combineCodeSet);
		System.out.println(responseCodeSet);
	}
	
	
}
