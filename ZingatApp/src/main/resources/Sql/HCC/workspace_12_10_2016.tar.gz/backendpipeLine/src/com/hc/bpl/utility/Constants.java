package com.hc.bpl.utility;

public class Constants {

	public static final String SOLRURL="solr_url";
	public static final String DEFAULT_SEARCH_FIELD="default_search_field";
	public static final String SOLR_FIELD="solr_field";

	public static final String DRIVER_NAME="driver_name";
	public static final String MYSQL_URL="mysqlUrl";
	public static final String MYSQL_USERNAME="mysqlUserName";
	public static final String MYSQL_PASSWORD="mysqlPassword";

	public static final String DOCUMENTUPDATEQUERY = "documentUpdatequery";
	public static final String SELECTQUERY = "selectQuery";
	public static final String ANALYSISPIPELINE = "analysis_pipeline";
	public static final String SPLITREGEX = "splitregex";
	public static final String SELECTCOUNTQUERY = "selectCountquery";
	public static final String SECTIONPATTERN = "SectionPattern";
	public static final String WORKTYPEPATTERN = "workTypePattern";
	public static final String COMBINEFILENAME = "combineFileName"; 
	public static final String NEGATIVEPATTERN_MIDDEL="negativePattern_middel";
	public static final String NEGATIVEPATTERN_START="negativePattern_START";
	public static String lUCENE_DIC_PATH="lucene_dic_path";


	public static final String EVIDENCE="evidence";
	public static final String NEGATIVE="negative";
	public static final String COMBINE="combine";
	public static final String COMBINE_REJECT="combine_Reject";
	public static final String COMBINESOLRURL = "combineSolrUrl";
}
