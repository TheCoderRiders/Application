package com.hc.bpl.dic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;

import com.hc.bpl.dto.AutoSuggestToken;
import com.hc.bpl.utility.Constants;


public class DictionaryLookup {

	
	
	public enum Type {
	    EVIDENCE, COMBINE,NEGATIVE,EVIDENCE_REJECT
	   
	}
	
	private SolrClient server;
	private String defaultSearchField;
	private  List<String> codeFieldMaping;
 //  private String filterQuery="icd_09_10: \"ICD10\"";
	public DictionaryLookup(String url,String defaultSearchField) {
		try {
			server=HccSolrClientUtil.getSolrClient( url);
			this.defaultSearchField=defaultSearchField;
		} catch (SolrServerException e) {
			e.printStackTrace();
		}
	}




	public Set<AutoSuggestToken> lookup(String queryString,String Type){
		SolrQuery query=new SolrQuery();
		query.setQuery(queryString);
	//	query.addFilterQuery(filterQuery);
		Set<AutoSuggestToken> responseSet=new HashSet<AutoSuggestToken>();
		try {
			QueryResponse qr=server.query(query);
			SolrDocumentList sdl=qr.getResults();
			for (SolrDocument solrDocument : sdl) {
				AutoSuggestToken autoSuggestToken=new AutoSuggestToken();
				autoSuggestToken.setCode(solrDocument.getFieldValue("code_id").toString());
				autoSuggestToken.setDesc(solrDocument.getFieldValue("code_description").toString().replace("'", "''"));
				autoSuggestToken.setType(Type);
				responseSet.add(autoSuggestToken);
			}

		} catch (SolrServerException | IOException e) {
					e.printStackTrace();
		}
		return responseSet;
	}
	
	public boolean checkWorddictionry(String queryString){
        boolean flag=false;
		SolrQuery query=new SolrQuery();
		query.setQuery("code_description_text:"+queryString);
		try {
			QueryResponse qr=server.query(query);
			if(qr.getResults().getNumFound()>0){
				flag=true;
			}
		} catch (SolrServerException | IOException e) {
					e.printStackTrace();
		}
		return flag;
	}
	
	public boolean checkStartWorddictionry(String queryString){
        boolean flag=false;
		SolrQuery query=new SolrQuery();
		query.setQuery(queryString+"\\ *");
		try {
			QueryResponse qr=server.query(query);
			if(qr.getResults().getNumFound()>0){
				flag=true;
			}
		} catch (SolrServerException | IOException e) {
					e.printStackTrace();
		}
		return flag;
	}
	

	public  void Close() {
		try {
			server.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
