package com.hc.bpl.doc.processor;

import java.io.File;



public interface Parser {

	public String  parseDcoument(File FileName) throws Exception;

}
