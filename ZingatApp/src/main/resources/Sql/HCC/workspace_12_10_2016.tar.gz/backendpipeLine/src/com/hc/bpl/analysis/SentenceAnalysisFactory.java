package com.hc.bpl.analysis;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.hc.bpl.dto.Document;

import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;



public class SentenceAnalysisFactory  implements AnalysisFactory {

	private SentenceModel model;
	private SentenceDetectorME sentenceDetector;	
	public static final String BPL_HOME=System.getProperty("bpl.home");

	public SentenceAnalysisFactory(){
		try {
			InputStream modelIn = new FileInputStream(BPL_HOME+"/conf/en-sent.bin");
			model = new SentenceModel(modelIn);
			sentenceDetector = new SentenceDetectorME(model);
		}
		catch (IOException e){
			e.printStackTrace();
		}
	}


	@Override
	public void analysisDocument(List<Document> documentList) {
		for (Document document : documentList) {
			List<String> lineList=new ArrayList<String>();
			Map<String,Map<String, String>> workTypeMap=document.getSection();
			for(String worktype:workTypeMap.keySet()){
				Map<String, String> sectionMap=workTypeMap.get(worktype);
				Map<String, List<String>> SectionLine=new HashMap<String, List<String>>();
				for(String s:sectionMap.keySet()){
					 List<String> SectionLineList=new ArrayList<String>();
					String [] a=sentenceDetector.sentDetect(sectionMap.get(s)); 
					for (int i = 0; i < a.length; i++) {
						lineList.add(a[i]);
						SectionLineList.add(a[i]);
					}
					SectionLine.put(s, SectionLineList);
				}	
				document.setLines(worktype, SectionLine);
				
			}
		}
	}
	public static void main(String a[]){
		SentenceAnalysisFactory sf=new SentenceAnalysisFactory();
		Document document=new Document();
		document.setDocument_contain(" Joanne is a 79-year-old morbidly obese white female being admitted to Riverside Nursing Center from Mercy Health Partners in Muskegon. She was admitted to that facility on 04/24/2016 with diagnosis of acute congestive heart failure with acute hypoxic and hypercarbic respiratory failure. She has a known history of coronary artery disease with multiple stents. She also has COPD, has been ongoing smoker up to her hospitalization. She was brought to this facility for rehabilitation. Prior to her hospitalization, she lived with her daughter.");
		List<Document> docList=new ArrayList<Document>();
		docList.add(document);
		Document document1=new Document();
		document1.setDocument_contain(" Joanne is a 79-year-old morbidly obese white female being admitted to Riverside Nursing Center from Mercy Health Partners in Muskegon. She was admitted to that facility on 04/24/2016 with diagnosis of acute congestive heart failure with acute hypoxic and hypercarbic respiratory failure. She has a known history of coronary artery disease with multiple stents. She also has COPD, has been ongoing smoker up to her hospitalization. She was brought to this facility for rehabilitation. Prior to her hospitalization, she lived with her daughter.");
		docList.add(document1);
		sf.analysisDocument(docList);
	}

}
