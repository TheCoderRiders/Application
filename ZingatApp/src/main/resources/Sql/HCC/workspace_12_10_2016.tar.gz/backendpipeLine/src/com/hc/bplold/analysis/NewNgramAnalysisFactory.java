package com.hc.bplold.analysis;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.hc.bpl.analysis.AnalysisFactory;
import com.hc.bpl.analysis.SentenceAnalysisFactory;
import com.hc.bpl.dic.DictionaryLookup;
import com.hc.bpl.dic.LuceneDictonary;
import com.hc.bpl.dto.AutoSuggestToken;
import com.hc.bpl.dto.Document;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;

public class NewNgramAnalysisFactory implements AnalysisFactory {

	private ConfigManager configManager;
	private DictionaryLookup dictionaryLookup;
	private Pattern pattern;
	private LuceneDictonary luceneDic;
	private Set<String> SetDontCode=new HashSet<>();{
		SetDontCode.add("FAMILY HISTORY");
	}
	public NewNgramAnalysisFactory() throws IOException {
		configManager=ConfigManager.getInstance();	
		pattern=Pattern.compile(configManager.getPropertie(Constants.SPLITREGEX));
		dictionaryLookup=new DictionaryLookup(configManager.getPropertie(Constants.SOLRURL), configManager.getPropertie(Constants.DEFAULT_SEARCH_FIELD));
		luceneDic=new LuceneDictonary(configManager.getPropertie(Constants.lUCENE_DIC_PATH));

	}

	@Override
	public void analysisDocument(List<Document> documentList) {
		for (Document document : documentList) {
			generateNgram(document);
		}
	}

	private  void generateNgram(Document document) {
		Map<String, AutoSuggestToken> suggestMap=new HashMap<String, AutoSuggestToken>();
		System.out.println(document.getDocument_id());
		for(String line:document.getLine()){

			NewNGramTokenizer tokenizer=tokenizer(line);
			if(tokenizer!=null){
				tokenizer.generateToken();
				Map<String,List<Token>> tokenMap=tokenizer.getToken();
				for(String token:tokenMap.keySet()) {
					Map<String, AutoSuggestToken> suggestResult=luceneDic.searchQuery("\""+token+"\"");

					if(suggestResult.size()>0){
						System.out.println(line);
						System.out.println(token);
						suggestMap.putAll(suggestResult);	
						System.out.println(suggestResult);
					}
				}
			}

		}
	//	document.setAutoSuggestMap(null, suggestMap);

	}

	public  NewNGramTokenizer tokenizer(String line){
		Matcher match=pattern.matcher(line);
		int  start=0;
		List<Token> tokenList=new ArrayList<Token>();
		while(match.find()){
			insertToken(line.toCharArray(),start,match.start(0)-start,tokenList);
			start=match.end(0);
		}
		insertToken(line.toCharArray(),start,line.length()-start,tokenList);
		if(tokenList.size()==0){
			return null;
		}if(tokenList.size()==16){
			for(Token s:tokenList){
				System.out.println(s.getTokenString() +" "+s.isFlag());
			}

		}
		return new NewNGramTokenizer(tokenList);
	}
	void  insertToken( char c[],int start,int len,List<Token> tokenList){
		String tokenString=new String( c, start, len).trim();
		if(!tokenString.isEmpty()){
			boolean isstart=false;
			boolean flag=luceneDic.searchWildQuery(tokenString+"\\ *");
			if(flag){
				isstart=flag;
			}else{
				flag=luceneDic.searchWildQuery("*\\ "+tokenString+"\\ *");
			}
			if(!flag){
				return;
			}
			Token token=new Token();
			token.setTokenString(tokenString);
			token.setLen(len);
			token.setOffset(start);
			token.setFlag(isstart);
			tokenList.add(token);

		}
	}

	class NewNGramTokenizer{
		private ArrayList<Token> output = new ArrayList<Token>();
		private List<Token> tokenList=new ArrayList<Token>();
		private Map<String,List<Token>> tokenMap=new HashMap<String, List<Token>>();
		private StringBuffer sb=new StringBuffer();
		public NewNGramTokenizer( List<Token> tokenList ){
			this.tokenList = tokenList;
		}
		public void generateToken() { 
			combine( 0 ); 
		}
		public Map<String,List<Token>> getToken(){
			return tokenMap;
		}
		private void combine(int start ){
			for( int i = start; i < tokenList.size(); ++i ){

				if(output.size()==0){
					if(!tokenList.get(i).isFlag()){
						continue;
					}
				}
				sb.append(tokenList.get(i).getTokenString()+" ");
				output.add(tokenList.get(i));
				tokenMap.put(sb.toString().trim(),	new ArrayList<Token>(output));
				if ( i < tokenList.size() ){

					combine( i + 1);

				}
				Token token =output.get( output.size() - 1 );
				sb.setLength(sb.length()-token.getTokenString().length()-1);
				output.remove( output.size() - 1 );

			}
		}



	}

	public static void main(String a[]) throws JsonGenerationException, JsonMappingException, IOException{
		System.setProperty("bpl.home","/home/local/EZDI/vishal.d/workspace/backendpipeLine");
		NewNgramAnalysisFactory nl=new NewNgramAnalysisFactory();
		SentenceAnalysisFactory sd=new SentenceAnalysisFactory();
		Document document=new Document();
		document.setDocument_contain("he had Typhoid pneumonia,Typhoid arthritis, unspecified site");
		Map<String,String> sectionMap=new HashMap<String, String>();
		sectionMap.put("data", "he had Typhoid pneumonia,Typhoid arthritis, unspecified site");
		document.setSection("data",sectionMap);
		List<Document> docList=new ArrayList<Document>();
		docList.add(document);
		sd.analysisDocument(docList);
		nl.analysisDocument(docList);

		ObjectMapper mapper = new ObjectMapper();
		ByteArrayOutputStream s=new ByteArrayOutputStream();
		mapper.writeValue(s, docList);
		System.out.println(new String(s.toByteArray()));
		s.flush();
		s.reset();
		s.close();

	}


}


