package com.hc.bpl.main;

import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import com.hc.bpl.analysis.AnalysisFactory;
import com.hc.bpl.doa.DBConnection;
import com.hc.bpl.doa.DocumentDao;
import com.hc.bpl.dto.Document;
import com.hc.bpl.utility.ConfigManager;
import com.hc.bpl.utility.Constants;



public class DocumentProcessor  extends Thread{

	private ConfigManager configManager;
	private List<AnalysisFactory> analysisFactoryList=new ArrayList<AnalysisFactory>();
	private String select_query;
	private final String PIPESEPARTOR="\\|";

	public DocumentProcessor(int start,int count,Timestamp date) {
		try{
			configManager=ConfigManager.getInstance();	
			select_query=preapareQuery(start, count, date,configManager.getPropertie(Constants.SELECTQUERY));	
			String [] classnameList=configManager.getPropertie(Constants.ANALYSISPIPELINE).split(PIPESEPARTOR);
			for (String classaname:classnameList){
				try {
					analysisFactoryList.add((AnalysisFactory)Class.forName(classaname).newInstance());
				} catch (InstantiationException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		}catch (Exception e) {
			throw e;
		}
	}

	@Override
	public void run() {
		DocumentDao documentDao=null;
		try{
			Connection conn=DBConnection.getConnection(configManager);
			documentDao=new DocumentDao(conn);  
			List<Document> documentList= documentDao.getDcuoment(select_query);
			for (AnalysisFactory analysisFactory:analysisFactoryList){
				analysisFactory.analysisDocument(documentList);
			}
			documentDao.updateDocuments(documentList);
			documentDao.close();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
            if(documentDao!=null){
            	documentDao.close();
            }
		}


	}

	private static String preapareQuery(int start,int count,Timestamp date,String rowQuery){	
		String query = rowQuery.replace("__document_parsed_datetime__", date.toString()).replace("__Start__", ""+start).replace("__count__", ""+count);
		return query;
	}
}
